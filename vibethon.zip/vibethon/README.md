# AIML Adventure Hub

A responsive AI/ML learning platform built for Vibethon with:

- Email/password authentication plus demo Google and GitHub OAuth flows
- Structured learning modules from Beginner to Advanced
- Compact visual aids and examples in every module
- In-browser coding playground with Python-first starter snippets
- Interactive mini-games for decision trees, classification, and neural network tuning
- Quiz system with MCQ and short code-style questions
- Real-world simulations for spam detection and image classification
- Dashboard with progress tracking, activity history, badges, streaks, and leaderboard

## Project structure

- `frontend/` contains the responsive UI, modals, dashboard, games, and playground
- `backend/` contains the Express API and JSON-backed data store

## Local setup

1. Open a terminal in `backend/`
2. Install dependencies if needed with `npm install`
3. Start the server with `npm start`
4. Open `http://localhost:5000`

## Main API routes

- `POST /api/users/register`
- `POST /api/users/login`
- `POST /api/users/oauth`
- `PATCH /api/users/:email/progress`
- `POST /api/quizzes/:id/submit`
- `POST /api/games/:id/score`
- `POST /api/playground/run`
- `GET /api/users/:email/dashboard`
- `GET /api/leaderboard`

## Deployment notes

This structure works well for Vercel, Netlify plus serverless backend adaptation, or a simple Node host. The frontend is static-friendly and the backend uses lightweight JSON storage for demo use.

## Future extensions

- Replace the playground preview endpoint with a true sandbox runner or Jupyter kernel
- Add real OAuth credentials for Google and GitHub
- Add voice narration, AI tutor chat, and multiplayer challenges
- Capture screenshots and demo links for final showcase submission
