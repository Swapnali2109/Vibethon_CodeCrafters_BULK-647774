# ⚡ Quick Start Guide - AIML Learning Platform

## 🎯 30 Seconds to Get Running

### Option 1: Using Command Prompt/PowerShell (Windows)
```powershell
cd d:\xampp\htdocs\vibethon\backend
npm install
npm start
```
Then open browser to: **http://localhost:5000**

### Option 2: Using Git Bash/Linux Terminal
```bash
cd /d/xampp/htdocs/vibethon/backend
npm install
npm start
```

## ✅ Verify It's Working

1. **Server Running?** → You should see:
   ```
   🚀 AIML Learning Platform running on http://localhost:5000
   📚 Browse to http://localhost:5000 to access the platform
   ```

2. **Browser Access?** → Go to: `http://localhost:5000`

3. **See Home Page?** → If yes, everything is installed correctly! 🎉

## 🚪 First Time Using the Platform?

1. **Click "Get Started Now"** or **"Login"** button at the top
2. **Sign Up** with any name and email
3. **Explore the platform!**

### Quick Actions:
- 📚 **Learning** → Take structured AIML courses
- 🎮 **Games** → Play interactive learning games
- 📝 **Quizzes** → Test your knowledge
- 📊 **Dashboard** → Check your progress and points
- 💻 **Code Practice** → Write ML code

## 🎓 Recommended Learning Path

**Day 1:** 
- Complete "Intro to Machine Learning" course (15 mins)
- Take "ML Basics Quiz" (10 mins)
- Play "Decision Tree Builder" game (10 mins)

**Day 2:**
- Learn about Neural Networks (20 mins)
- Try "Neural Network Trainer" game
- Play "Clustering Quest"

**Day 3:**
- Explore NLP course
- Take advanced quizzes
- Practice code challenges

## 🐛 Troubleshooting

### ❌ "Cannot find module 'express'"
**Solution:** You haven't installed dependencies yet
```bash
npm install
```

### ❌ "Port 5000 already in use"
**Solution:** Either:
- Close the other application using port 5000
- Or run on a different port:
  ```bash
  SET PORT=3000 && npm start
  ```

### ❌ Page shows blank/white screen
**Solution:**
- Clear browser cache (Ctrl+Shift+Delete)
- Refresh page (Ctrl+R)
- Try a different browser

### ❌ Can't login/signup
**Solution:**
- Make sure backend is running (check terminal)
- Refresh page (F5)
- Check browser console for errors (F12)

## 📈 What to Expect

- ✅ Fully responsive design (works on phone, tablet, desktop)
- ✅ Smooth animations throughout
- ✅ Instant feedback on quizzes
- ✅ Real-time game visualizations
- ✅ Progress saved in browser
- ✅ Points & achievements system
- ✅ Global leaderboard

## 🎮 Featured Games Explained

### 1. **Decision Tree Builder**
```
Your Goal: Create optimal decision trees
How to Play: Select features to split, maximize accuracy
Earn: 50 points per split
Difficulty: Increases with nodes added
```

### 2. **Neural Network Trainer**
```
Your Goal: Train a network to 95% accuracy
How to Play: Click "Train Step" repeatedly
Visualizes: Real-time accuracy and network state
Earn: 10 points per epoch + bonuses
```

### 3. **Clustering Quest**
```
Your Goal: Optimize cluster centers
How to Play: Click "Optimize" to run K-means
Metric: Silhouette score displayed
Earn: Points based on score
```

## 💎 Unlock Features

- **Reach Level 2** (500 points) → Advanced courses unlock
- **Complete Course** → Receive badge 🏅
- **Score 100% Quiz** → "Perfect Score" badge 🎯
- **Win Game** → Game-specific badge 🎮

## 📚 Content Available NOW

### Courses (4 total)
1. Introduction to Machine Learning
2. Deep Learning Fundamentals  
3. Natural Language Processing
4. Computer Vision

### Quizzes (2 sample)
1. ML Basics Quiz (5 questions)
2. Neural Networks Quiz (2 questions)

### Games (3 interactive)
1. Decision Tree Builder
2. Neural Network Trainer
3. Clustering Quest

### Code Challenges (4 + samples)
1. K-Nearest Neighbors implementation
2. Confusion Matrix calculation
3. Decision Tree Entropy
4. Neural Network Forward Pass

## 🔐 Data Saving

- **Browser Storage**: Your progress is saved in browser localStorage
- **No Cloud Sync**: Upgrade to save in database later
- **Private**: Your data stays on your computer
- **Clear Cache Warning**: Clearing cache deletes progress

## ⌨️ Keyboard Shortcuts

- `Escape` → Close modals/dialogs
- `Ctrl+F` → Find/search on page
- `F5` or `Ctrl+R` → Refresh page
- `F12` → Open developer tools (for debugging)

## 📞 Quick Help

**Q: How do I earn more points?**
A: Complete courses (+50), pass quizzes (+10-100), win games (+25-100), solve code challenges (+50)

**Q: Can I use this offline?**
A: Mostly yes! Courses and games work offline after loading

**Q: How do levels work?**
A: 500 points = 1 level. Check your profile!

**Q: Where's my progress saved?**
A: Browser storage. Don't clear cache or you lose it!

**Q: Can I export my progress?**
A: Not yet - coming soon!

## 🚀 Next Steps

1. ✅ Open the platform
2. ✅ Sign up/Login  
3. ✅ Start a course
4. ✅ Take your first quiz
5. ✅ Play a game
6. ✅ Check your dashboard
7. ✅ Climb the leaderboard!

## 📱 Mobile Users

The platform is fully responsive! 
- Works great on phones
- Touch-friendly interface
- Games work on mobile
- All features accessible

## 🎓 Pro Tips

1. **Try all games** - Each teaches different concepts
2. **Re-take quizzes** - Improve your score
3. **Read feedback** - Learn from mistakes
4. **Watch accuracy** - In Neural Network game
5. **Optimize clusters** - Multiple times
6. **Code challenges** - Build real skills
7. **Check leaderboard** - Stay motivated

## 📊 Dashboard Guide

| Section | Shows |
|---------|-------|
| User Profile | Your name & level |
| Statistics | Points, courses, quizzes |
| Achievements | Earned badges |
| Progress | Course completion %age |
| Leaderboard | Top users & your rank |

---

**Ready? Let's start learning! 🚀**

For full documentation, see [README.md](README.md)
