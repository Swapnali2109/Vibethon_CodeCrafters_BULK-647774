// ========================
// API Documentation
// ========================

/**
 * AIML Learning Platform API Documentation
 * Version: 1.0.0
 * Base URL: http://localhost:5000/api
 */

// ========================
// Authentication Endpoints
// ========================

/**
 * POST /api/users/register
 * Register a new user
 * 
 * Request Body:
 * {
 *   "name": "John Doe",
 *   "email": "john@example.com"
 * }
 * 
 * Response: 200 OK
 * {
 *   "success": true,
 *   "user": {
 *     "id": 1234567890,
 *     "name": "John Doe",
 *     "email": "john@example.com",
 *     "points": 0,
 *     "badges": [],
 *     "progress": {},
 *     "level": 1,
 *     "createdAt": "2024-04-15T10:00:00Z"
 *   }
 * }
 * 
 * Error Response: 400 Bad Request
 * {
 *   "error": "User already exists"
 * }
 */

/**
 * POST /api/users/login
 * Login an existing user
 * 
 * Request Body:
 * {
 *   "email": "john@example.com"
 * }
 * 
 * Response: 200 OK
 * {
 *   "success": true,
 *   "user": { ...user object... }
 * }
 * 
 * Error Response: 401 Unauthorized
 * {
 *   "error": "User not found"
 * }
 */

/**
 * GET /api/users/:email
 * Get user profile by email
 * 
 * Response: 200 OK
 * {
 *   "id": 1234567890,
 *   "name": "John Doe",
 *   "email": "john@example.com",
 *   "points": 500,
 *   "badges": ["course_beginner", "game_1_level_1"],
 *   "progress": {
 *     "course_1": { "modules_completed": 3 }
 *   },
 *   "level": 2,
 *   "createdAt": "2024-04-15T10:00:00Z"
 * }
 * 
 * Error Response: 404 Not Found
 * {
 *   "error": "User not found"
 * }
 */

// ========================
// Course Endpoints
// ========================

/**
 * GET /api/courses
 * Get all available courses
 * 
 * Response: 200 OK
 * [
 *   {
 *     "id": 1,
 *     "title": "Introduction to Machine Learning",
 *     "description": "Learn the fundamentals of ML...",
 *     "level": "Beginner",
 *     "duration": "4 weeks",
 *     "image": "🤖",
 *     "modules": [
 *       {
 *         "id": 1,
 *         "name": "What is Machine Learning?",
 *         "content": "Machine Learning is...",
 *         "videoUrl": "https://...",
 *         "completed": false
 *       }
 *     ]
 *   }
 * ]
 */

/**
 * GET /api/courses/:id
 * Get specific course details
 * 
 * Response: 200 OK
 * {
 *   "id": 1,
 *   "title": "Introduction to Machine Learning",
 *   ...
 * }
 * 
 * Error Response: 404 Not Found
 * {
 *   "error": "Course not found"
 * }
 */

// ========================
// Quiz Endpoints
// ========================

/**
 * GET /api/quizzes
 * Get all available quizzes
 * 
 * Response: 200 OK
 * [
 *   {
 *     "id": 1,
 *     "title": "ML Basics Quiz",
 *     "courseId": 1,
 *     "difficulty": "Beginner",
 *     "questions": [
 *       {
 *         "id": 1,
 *         "question": "What is supervised learning?",
 *         "options": ["Option A", "Option B", "Option C", "Option D"],
 *         "correct": 1
 *       }
 *     ]
 *   }
 * ]
 */

/**
 * POST /api/quizzes/:id/submit
 * Submit quiz answers and get score
 * 
 * Request Body:
 * {
 *   "answers": [1, 2, 0, 1, 2],
 *   "userEmail": "john@example.com"
 * }
 * 
 * Response: 200 OK
 * {
 *   "score": 80,
 *   "correct": 4,
 *   "total": 5,
 *   "results": [
 *     {
 *       "question": "What is supervised learning?",
 *       "userAnswer": "Option B",
 *       "correctAnswer": "Option B",
 *       "isCorrect": true
 *     }
 *   ]
 * }
 */

// ========================
// Game Endpoints
// ========================

/**
 * GET /api/games
 * Get all available games
 * 
 * Response: 200 OK
 * [
 *   {
 *     "id": 1,
 *     "name": "Decision Tree Builder",
 *     "description": "Build decision trees by making optimal...",
 *     "image": "🌳",
 *     "category": "Algorithms"
 *   }
 * ]
 */

/**
 * POST /api/games/:id/score
 * Record game score
 * 
 * Request Body:
 * {
 *   "score": 500,
 *   "userEmail": "john@example.com",
 *   "level": 3
 * }
 * 
 * Response: 200 OK
 * {
 *   "success": true,
 *   "newScore": 1500
 * }
 */

// ========================
// Error Codes
// ========================

/**
 * 200 - OK: Request successful
 * 400 - Bad Request: Invalid input
 * 401 - Unauthorized: User not found
 * 404 - Not Found: Resource not found
 * 500 - Internal Server Error: Server error
 */

// ========================
// Rate Limiting (Planned)
// ========================

/**
 * - 100 requests per minute per IP
 * - 1000 requests per hour per user
 */

// ========================
// Usage Examples
// ========================

/**
 * Example: Register a user
 * 
 * curl -X POST http://localhost:5000/api/users/register \
 *   -H "Content-Type: application/json" \
 *   -d '{"name": "Jane Doe", "email": "jane@example.com"}'
 * 
 */

/**
 * Example: Get all courses
 * 
 * curl http://localhost:5000/api/courses
 * 
 */

/**
 * Example: Submit a quiz
 * 
 * curl -X POST http://localhost:5000/api/quizzes/1/submit \
 *   -H "Content-Type: application/json" \
 *   -d '{"answers": [1,2,0], "userEmail": "john@example.com"}'
 * 
 */

// ========================
// Future Enhancements
// ========================

/**
 * Planned Endpoints:
 * 
 * PROGRESS:
 * - GET /api/progress/:userId
 * - PUT /api/progress/:userId
 * 
 * ACHIEVEMENTS:
 * - GET /api/achievements/:userId
 * - POST /api/achievements/:userId/unlock
 * 
 * LEADERBOARD:
 * - GET /api/leaderboard
 * - GET /api/leaderboard/:userId/rank
 * 
 * RECOMMENDATIONS:
 * - GET /api/recommendations/:userId
 * - GET /api/learning-path/:userId
 * 
 * ANALYTICS:
 * - GET /api/analytics/:userId/performance
 * - GET /api/analytics/:userId/time-spent
 * - GET /api/analytics/:userId/mastery
 * 
 * CERTIFICATES:
 * - POST /api/certificates/generate/:userId/:courseId
 * - GET /api/certificates/:userId
 */

module.exports = {
    API_DOCS: "See comments above for API documentation"
};
