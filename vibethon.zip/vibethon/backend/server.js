const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../frontend')));

const dataDir = path.join(__dirname, 'data');
const files = {
  users: path.join(dataDir, 'users.json'),
  courses: path.join(dataDir, 'courses.json'),
  quizzes: path.join(dataDir, 'quizzes.json'),
  games: path.join(dataDir, 'games.json'),
  simulations: path.join(dataDir, 'simulations.json'),
  classrooms: path.join(dataDir, 'classrooms.json'),
  questions: path.join(dataDir, 'questions.json')
};

if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

function hashPassword(password = '') {
  return crypto.createHash('sha256').update(password).digest('hex');
}

function readJson(filePath, fallback = []) {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch (error) {
    return fallback;
  }
}

function writeJson(filePath, data) {
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

function ensureSeedFile(filePath, seedData, shouldReplace) {
  if (!fs.existsSync(filePath)) {
    writeJson(filePath, seedData);
    return;
  }

  const current = readJson(filePath, null);
  if (shouldReplace(current)) {
    writeJson(filePath, seedData);
  }
}

function defaultUserShape(user = {}) {
  const points = Number(user.points || 0);
  const completedModules = Number(
    user.completedModules || Object.keys(user.progress || {}).filter((key) => user.progress[key]?.completed).length || 0
  );

  return {
    id: user.id || Date.now(),
    name: user.name || 'Learner',
    email: user.email || '',
    passwordHash: user.passwordHash || '',
    authProviders: Array.isArray(user.authProviders) ? user.authProviders : ['email'],
    points,
    level: Math.max(1, Math.floor(points / 300) + 1),
    badges: Array.isArray(user.badges) ? user.badges : [],
    streak: user.streak || { current: 0, best: 0, lastActive: null },
    progress: user.progress || {},
    completedModules,
    quizHistory: Array.isArray(user.quizHistory) ? user.quizHistory : [],
    gameHistory: Array.isArray(user.gameHistory) ? user.gameHistory : [],
    activityHistory: Array.isArray(user.activityHistory) ? user.activityHistory.slice(-30) : [],
    codeRuns: Number(user.codeRuns || 0),
    createdAt: user.createdAt || new Date().toISOString(),
    lastLogin: user.lastLogin || null
  };
}

function initializeDataFiles() {
  ensureSeedFile(files.users, [], (current) => !Array.isArray(current));
  ensureSeedFile(files.courses, getCourseData(), (current) => !Array.isArray(current) || current.length < 6 || !current[0]?.modules?.[0]?.visualAid);
  ensureSeedFile(files.quizzes, getQuizData(), (current) => !Array.isArray(current) || current.length < 6 || !current[0]?.questions?.some((question) => question.type === 'code'));
  ensureSeedFile(files.games, getGameData(), (current) => !Array.isArray(current) || current.length < 3 || !current[0]?.goal);
  ensureSeedFile(files.simulations, getSimulationData(), (current) => !Array.isArray(current) || current.length < 2);
  ensureSeedFile(files.classrooms, [], (current) => !Array.isArray(current));
  ensureSeedFile(files.questions, [], (current) => !Array.isArray(current));

  const users = readJson(files.users, []).map(defaultUserShape);
  writeJson(files.users, users);
}

function loadUsers() {
  return readJson(files.users, []).map(defaultUserShape);
}

function saveUsers(users) {
  writeJson(files.users, users.map(defaultUserShape));
}

function addActivity(user, type, title, details = '') {
  user.activityHistory.unshift({
    id: Date.now() + Math.floor(Math.random() * 1000),
    type,
    title,
    details,
    timestamp: new Date().toISOString()
  });
  user.activityHistory = user.activityHistory.slice(0, 30);
}

function awardPoints(user, amount) {
  user.points += amount;
  user.level = Math.max(1, Math.floor(user.points / 300) + 1);
  const milestoneBadges = [
    { threshold: 250, badge: 'Bronze Builder' },
    { threshold: 600, badge: 'Silver Strategist' },
    { threshold: 1200, badge: 'Gold Innovator' }
  ];

  milestoneBadges.forEach((item) => {
    if (user.points >= item.threshold && !user.badges.includes(item.badge)) {
      user.badges.push(item.badge);
    }
  });
}

function updateStreak(user) {
  const today = new Date().toISOString().slice(0, 10);
  const streak = user.streak || { current: 0, best: 0, lastActive: null };

  if (streak.lastActive === today) {
    user.streak = streak;
    return;
  }

  if (streak.lastActive) {
    const last = new Date(streak.lastActive);
    const now = new Date(today);
    const diff = Math.round((now - last) / 86400000);
    streak.current = diff === 1 ? streak.current + 1 : 1;
  } else {
    streak.current = 1;
  }

  streak.lastActive = today;
  streak.best = Math.max(streak.best || 0, streak.current);
  user.streak = streak;
}

function sanitizeUser(user) {
  const safeUser = { ...user };
  delete safeUser.passwordHash;
  return safeUser;
}

function getLeaderboard() {
  return loadUsers()
    .sort((a, b) => b.points - a.points)
    .slice(0, 10)
    .map((user, index) => ({
      rank: index + 1,
      name: user.name,
      level: user.level,
      points: user.points,
      streak: user.streak?.current || 0,
      badges: user.badges.length
    }));
}

function loadClassrooms() {
  return readJson(files.classrooms, []);
}

function saveClassrooms(classrooms) {
  writeJson(files.classrooms, classrooms);
}

function loadQuestions() {
  return readJson(files.questions, []);
}

function saveQuestions(questions) {
  writeJson(files.questions, questions);
}

function generateClassroomCode(name = 'ROOM') {
  const base = String(name).replace(/[^a-z0-9]/gi, '').toUpperCase().slice(0, 4) || 'ROOM';
  return `${base}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
}

function generateTutorReply(question) {
  const text = String(question || '').toLowerCase();

  if (text.includes('overfitting')) {
    return 'Overfitting means the model memorizes training data and struggles on new examples. Try simpler models, more data, or regularization.';
  }
  if (text.includes('decision tree')) {
    return 'Decision trees work by choosing splits that reduce uncertainty. Features with stronger information gain are usually better early splits.';
  }
  if (text.includes('neural') || text.includes('network')) {
    return 'Neural networks learn through repeated weight updates. Watch learning rate, epochs, and validation accuracy when tuning them.';
  }
  if (text.includes('precision') || text.includes('recall')) {
    return 'Precision asks how many predicted positives were correct. Recall asks how many real positives you found. The right tradeoff depends on the problem.';
  }

  return 'Start by defining the task type, the data you have, and the metric you care about. That usually narrows the right AIML approach quickly.';
}

function buildDashboard(user) {
  const courses = readJson(files.courses, []);
  const quizzes = readJson(files.quizzes, []);
  const games = readJson(files.games, []);

  const courseProgress = courses.map((course) => {
    const completed = course.modules.filter((module) => user.progress?.[`${course.id}-${module.id}`]?.completed).length;
    const total = course.modules.length;
    return {
      id: course.id,
      title: course.title,
      level: course.level,
      completed,
      total,
      percent: total ? Math.round((completed / total) * 100) : 0
    };
  });

  const quizScores = quizzes.map((quiz) => {
    const attempts = user.quizHistory.filter((entry) => entry.quizId === quiz.id);
    const bestScore = attempts.length ? Math.max(...attempts.map((entry) => entry.score)) : 0;
    return {
      id: quiz.id,
      title: quiz.title,
      difficulty: quiz.difficulty,
      attempts: attempts.length,
      bestScore
    };
  });

  const gamePerformance = games.map((game) => {
    const attempts = user.gameHistory.filter((entry) => entry.gameId === game.id);
    const bestScore = attempts.length ? Math.max(...attempts.map((entry) => entry.score)) : 0;
    return {
      id: game.id,
      name: game.name,
      category: game.category,
      attempts: attempts.length,
      bestScore
    };
  });

  return {
    user: sanitizeUser(user),
    overview: {
      points: user.points,
      level: user.level,
      completedModules: user.completedModules,
      quizzesTaken: user.quizHistory.length,
      codeRuns: user.codeRuns,
      streak: user.streak
    },
    courseProgress,
    quizScores,
    gamePerformance,
    recentActivity: user.activityHistory.slice(0, 8),
    leaderboard: getLeaderboard()
  };
}

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});
app.post('/api/users/register', (req, res) => {
  const { name, email, password } = req.body;
  const users = loadUsers();
  const normalizedEmail = String(email || '').trim().toLowerCase();

  if (!name || !normalizedEmail || !password) {
    return res.status(400).json({ error: 'Name, email, and password are required.' });
  }

  if (users.some((user) => user.email === normalizedEmail)) {
    return res.status(400).json({ error: 'An account with this email already exists.' });
  }

  const user = defaultUserShape({
    id: Date.now(),
    name: String(name).trim(),
    email: normalizedEmail,
    passwordHash: hashPassword(password),
    authProviders: ['email'],
    createdAt: new Date().toISOString()
  });

  updateStreak(user);
  addActivity(user, 'account', 'Account created', 'Signed up with email and password.');
  users.push(user);
  saveUsers(users);

  res.json({ success: true, user: sanitizeUser(user) });
});

app.post('/api/users/login', (req, res) => {
  const { email, password } = req.body;
  const normalizedEmail = String(email || '').trim().toLowerCase();
  const users = loadUsers();
  const user = users.find((entry) => entry.email === normalizedEmail);

  if (!user) {
    return res.status(401).json({ error: 'User not found.' });
  }

  const isLegacyUser = !user.passwordHash;
  const isValid = isLegacyUser ? Boolean(password) : user.passwordHash === hashPassword(password);

  if (!isValid) {
    return res.status(401).json({ error: 'Invalid password.' });
  }

  if (isLegacyUser) {
    user.passwordHash = hashPassword(password);
    if (!user.authProviders.includes('email')) {
      user.authProviders.push('email');
    }
  }

  user.lastLogin = new Date().toISOString();
  updateStreak(user);
  addActivity(user, 'account', 'Logged in', 'Continued learning session.');
  saveUsers(users);

  res.json({ success: true, user: sanitizeUser(user) });
});

app.post('/api/users/oauth', (req, res) => {
  const { provider, email, name } = req.body;
  const normalizedProvider = String(provider || '').toLowerCase();
  const normalizedEmail = String(email || '').trim().toLowerCase();
  const allowedProviders = ['google', 'github'];

  if (!allowedProviders.includes(normalizedProvider) || !normalizedEmail || !name) {
    return res.status(400).json({ error: 'Valid provider, name, and email are required.' });
  }

  const users = loadUsers();
  let user = users.find((entry) => entry.email === normalizedEmail);

  if (!user) {
    user = defaultUserShape({
      id: Date.now(),
      name: String(name).trim(),
      email: normalizedEmail,
      authProviders: [normalizedProvider],
      createdAt: new Date().toISOString()
    });
    updateStreak(user);
    addActivity(user, 'account', 'Account created', `Signed up with ${normalizedProvider}.`);
    users.push(user);
  } else if (!user.authProviders.includes(normalizedProvider)) {
    user.authProviders.push(normalizedProvider);
  }

  user.lastLogin = new Date().toISOString();
  updateStreak(user);
  addActivity(user, 'account', 'Social login', `Signed in with ${normalizedProvider}.`);
  saveUsers(users);

  res.json({ success: true, user: sanitizeUser(user) });
});

app.post('/api/users/logout', (req, res) => {
  res.json({ success: true });
});

app.get('/api/users/:email/dashboard', (req, res) => {
  const email = String(req.params.email || '').trim().toLowerCase();
  const user = loadUsers().find((entry) => entry.email === email);

  if (!user) {
    return res.status(404).json({ error: 'User not found.' });
  }

  res.json(buildDashboard(user));
});

app.patch('/api/users/:email/progress', (req, res) => {
  const email = String(req.params.email || '').trim().toLowerCase();
  const { courseId, moduleId, completed, title } = req.body;
  const users = loadUsers();
  const user = users.find((entry) => entry.email === email);

  if (!user) {
    return res.status(404).json({ error: 'User not found.' });
  }

  const progressKey = `${courseId}-${moduleId}`;
  const wasCompleted = Boolean(user.progress?.[progressKey]?.completed);
  user.progress[progressKey] = {
    courseId,
    moduleId,
    completed: Boolean(completed),
    updatedAt: new Date().toISOString()
  };

  user.completedModules = Object.values(user.progress).filter((entry) => entry.completed).length;

  if (!wasCompleted && completed) {
    awardPoints(user, 40);
    addActivity(user, 'module', 'Module completed', title || `Completed module ${moduleId}.`);
  }

  saveUsers(users);
  res.json({ success: true, user: sanitizeUser(user), dashboard: buildDashboard(user) });
});

app.post('/api/quizzes/:id/submit', (req, res) => {
  const quizId = Number(req.params.id);
  const { answers = [], userEmail } = req.body;
  const quizzes = readJson(files.quizzes, []);
  const quiz = quizzes.find((entry) => entry.id === quizId);

  if (!quiz) {
    return res.status(404).json({ error: 'Quiz not found.' });
  }

  const results = quiz.questions.map((question, index) => {
    const submitted = answers[index];
    let isCorrect = false;

    if (question.type === 'mcq') {
      isCorrect = Number(submitted) === question.correct;
    } else {
      const answerText = String(submitted || '').toLowerCase();
      isCorrect = question.expectedKeywords.every((keyword) => answerText.includes(keyword.toLowerCase()));
    }

    return {
      id: question.id,
      prompt: question.prompt,
      submitted,
      isCorrect
    };
  });

  const correct = results.filter((entry) => entry.isCorrect).length;
  const score = Math.round((correct / quiz.questions.length) * 100);
  const feedback = score >= 80 ? quiz.successFeedback : quiz.retryFeedback;
  let dashboard = null;

  if (userEmail) {
    const users = loadUsers();
    const user = users.find((entry) => entry.email === String(userEmail).trim().toLowerCase());
    if (user) {
      const pointsAwarded = Math.max(20, Math.round(score / 4));
      awardPoints(user, pointsAwarded);
      user.quizHistory.unshift({
        quizId,
        title: quiz.title,
        score,
        difficulty: quiz.difficulty,
        submittedAt: new Date().toISOString()
      });
      addActivity(user, 'quiz', 'Quiz submitted', `${quiz.title} scored ${score}%.`);
      saveUsers(users);
      dashboard = buildDashboard(user);
    }
  }

  res.json({
    score,
    correct,
    total: quiz.questions.length,
    results,
    feedback,
    dashboard
  });
});
app.post('/api/games/:id/score', (req, res) => {
  const gameId = Number(req.params.id);
  const { userEmail, score = 0, title = 'Game session', achievement = '' } = req.body;
  const games = readJson(files.games, []);
  const game = games.find((entry) => entry.id === gameId);

  if (!game) {
    return res.status(404).json({ error: 'Game not found.' });
  }

  const users = loadUsers();
  const user = users.find((entry) => entry.email === String(userEmail || '').trim().toLowerCase());

  if (!user) {
    return res.status(404).json({ error: 'User not found.' });
  }

  const normalizedScore = Math.max(0, Number(score) || 0);
  awardPoints(user, Math.min(80, Math.round(normalizedScore / 2)));
  user.gameHistory.unshift({
    gameId,
    score: normalizedScore,
    title: title || game.name,
    achievement,
    playedAt: new Date().toISOString()
  });

  if (achievement && !user.badges.includes(achievement)) {
    user.badges.push(achievement);
  }

  addActivity(user, 'game', 'Game completed', `${game.name} score ${normalizedScore}.`);
  saveUsers(users);

  res.json({ success: true, dashboard: buildDashboard(user) });
});

app.post('/api/playground/run', (req, res) => {
  const { language = 'python', code = '', userEmail = '' } = req.body;
  const normalizedLanguage = String(language).toLowerCase();
  const output = [];

  if (!String(code).trim()) {
    return res.status(400).json({ error: 'Code is required.' });
  }

  output.push(`Runner: ${normalizedLanguage.toUpperCase()} sandbox preview`);

  if (normalizedLanguage === 'python') {
    if (code.includes('for ') || code.includes('range(')) {
      output.push('Detected an iteration block. This is useful for training loops.');
    }
    if (code.includes('fit(') || code.includes('train')) {
      output.push('Model training step recognized.');
    }
    if (code.includes('print(')) {
      output.push('Print statements would stream their values here in a full runner.');
    }
  } else {
    if (code.includes('function') || code.includes('=>')) {
      output.push('Function definition recognized.');
    }
    if (code.includes('console.log')) {
      output.push('Console output would appear here in a full runner.');
    }
  }

  output.push('Static runner mode: syntax is accepted and concept feedback is available.');

  let dashboard = null;
  if (userEmail) {
    const users = loadUsers();
    const user = users.find((entry) => entry.email === String(userEmail).trim().toLowerCase());
    if (user) {
      user.codeRuns += 1;
      awardPoints(user, 15);
      addActivity(user, 'playground', 'Code executed', `Ran ${normalizedLanguage} playground code.`);
      saveUsers(users);
      dashboard = buildDashboard(user);
    }
  }

  res.json({
    success: true,
    output: output.join('\n'),
    hint: 'For live execution, connect this endpoint to a sandbox or notebook kernel later.',
    dashboard
  });
});

app.get('/api/courses', (req, res) => {
  res.json(readJson(files.courses, []));
});

app.get('/api/quizzes', (req, res) => {
  res.json(readJson(files.quizzes, []));
});

app.get('/api/games', (req, res) => {
  res.json(readJson(files.games, []));
});

app.get('/api/simulations', (req, res) => {
  res.json(readJson(files.simulations, []));
});

app.get('/api/leaderboard', (req, res) => {
  res.json(getLeaderboard());
});

app.get('/api/questions', (req, res) => {
  res.json(loadQuestions().slice(0, 20));
});

app.post('/api/questions', (req, res) => {
  const { question, userEmail = '', authorName = 'Guest learner' } = req.body;
  if (!String(question || '').trim()) {
    return res.status(400).json({ error: 'Question is required.' });
  }

  const entry = {
    id: Date.now(),
    question: String(question).trim(),
    authorName,
    userEmail,
    answer: generateTutorReply(question),
    createdAt: new Date().toISOString()
  };

  const questions = loadQuestions();
  questions.unshift(entry);
  saveQuestions(questions.slice(0, 30));

  if (userEmail) {
    const users = loadUsers();
    const user = users.find((item) => item.email === String(userEmail).trim().toLowerCase());
    if (user) {
      awardPoints(user, 5);
      addActivity(user, 'question', 'Question asked', entry.question);
      saveUsers(users);
    }
  }

  res.json({ success: true, entry, questions: loadQuestions().slice(0, 20) });
});

app.get('/api/classrooms', (req, res) => {
  res.json(loadClassrooms());
});

app.post('/api/classrooms', (req, res) => {
  const { name, creatorEmail = '', creatorName = 'Host' } = req.body;
  if (!String(name || '').trim()) {
    return res.status(400).json({ error: 'Classroom name is required.' });
  }

  const classrooms = loadClassrooms();
  const classroom = {
    id: Date.now(),
    name: String(name).trim(),
    code: generateClassroomCode(name),
    creatorEmail,
    creatorName,
    members: [{ name: creatorName, email: creatorEmail || '' }],
    questions: [],
    createdAt: new Date().toISOString()
  };

  classrooms.unshift(classroom);
  saveClassrooms(classrooms);

  if (creatorEmail) {
    const users = loadUsers();
    const user = users.find((item) => item.email === String(creatorEmail).trim().toLowerCase());
    if (user) {
      awardPoints(user, 15);
      addActivity(user, 'classroom', 'Classroom created', `${classroom.name} (${classroom.code})`);
      saveUsers(users);
    }
  }

  res.json({ success: true, classroom, classrooms: loadClassrooms() });
});

app.post('/api/classrooms/join', (req, res) => {
  const { code, userEmail = '', name = 'Learner' } = req.body;
  const classrooms = loadClassrooms();
  const classroom = classrooms.find((item) => item.code === String(code || '').trim().toUpperCase());

  if (!classroom) {
    return res.status(404).json({ error: 'Classroom not found.' });
  }

  const alreadyJoined = classroom.members.some((member) => {
    const sameEmail = userEmail && member.email && member.email === userEmail;
    const sameGuestName = !userEmail && !member.email && member.name === name;
    return sameEmail || sameGuestName;
  });
  if (!alreadyJoined) {
    classroom.members.push({ name, email: userEmail || '' });
  }

  saveClassrooms(classrooms);

  if (userEmail) {
    const users = loadUsers();
    const user = users.find((item) => item.email === String(userEmail).trim().toLowerCase());
    if (user) {
      awardPoints(user, 10);
      addActivity(user, 'classroom', 'Joined classroom', `${classroom.name} (${classroom.code})`);
      saveUsers(users);
    }
  }

  res.json({ success: true, classroom, classrooms: loadClassrooms() });
});

function getCourseData() {
  return [
    {
      id: 1,
      title: 'AI Foundations Sprint',
      description: 'Build confidence with the language, workflow, and mental models behind practical AI systems.',
      level: 'Beginner',
      duration: '2 weeks',
      image: 'brain',
      modules: [
        {
          id: 1,
          name: 'How machines learn from examples',
          summary: 'Understand data, patterns, labels, and prediction loops.',
          content: 'Machine learning is about mapping examples to useful behavior. We gather examples, represent them as features, train a model, and test whether it generalizes to new data.',
          examples: ['Email spam filtering', 'Movie recommendation', 'Fraud alerts'],
          visualAid: { title: 'Learning loop', labels: ['Data', 'Features', 'Training', 'Prediction'], values: [85, 70, 90, 78] }
        },
        {
          id: 2,
          name: 'Supervised vs unsupervised learning',
          summary: 'See when labels matter and when pattern discovery takes over.',
          content: 'Supervised learning uses labeled examples to predict a target. Unsupervised learning groups or compresses data when labels do not exist yet.',
          examples: ['House price prediction', 'Customer segmentation', 'Anomaly clustering'],
          visualAid: { title: 'Task map', labels: ['Labeled data', 'Prediction', 'Grouping', 'Pattern search'], values: [90, 88, 60, 72] }
        },
        {
          id: 3,
          name: 'Evaluation, bias, and overfitting',
          summary: 'Measure what matters and avoid models that only memorize.',
          content: 'Good models perform well on new data. Train-test splits, validation, and metrics like accuracy, precision, and recall help reveal whether the model is trustworthy.',
          examples: ['Spam detection metrics', 'Precision for medical alerts', 'Validation split strategy'],
          visualAid: { title: 'Healthy evaluation', labels: ['Train', 'Validate', 'Test', 'Monitor'], values: [75, 80, 78, 65] }
        }
      ]
    },
    {
      id: 2,
      title: 'ML Workflow Builder',
      description: 'Move from raw data to deployable models with strong habits around preprocessing and experimentation.',
      level: 'Beginner',
      duration: '3 weeks',
      image: 'database',
      modules: [
        {
          id: 1,
          name: 'Collecting and cleaning data',
          summary: 'Handle nulls, duplicates, outliers, and leakage risks.',
          content: 'Raw data is noisy. Before training, we detect missing values, remove duplicates, normalize scales, and watch for hidden leakage that makes evaluation misleading.',
          examples: ['Missing age values', 'Duplicate transactions', 'Scaling sensor features'],
          visualAid: { title: 'Data hygiene', labels: ['Clean', 'Scale', 'Encode', 'Split'], values: [82, 74, 68, 88] }
        },
        {
          id: 2,
          name: 'Feature engineering',
          summary: 'Turn raw signals into stronger predictive clues.',
          content: 'Feature engineering shapes inputs so the model can discover important patterns faster. Common moves include bucketing, normalization, and domain-specific feature creation.',
          examples: ['Day of week features', 'Text token counts', 'Average basket size'],
          visualAid: { title: 'Feature lift', labels: ['Raw input', 'Derived ratios', 'Encoding', 'Selection'], values: [40, 70, 80, 76] }
        },
        {
          id: 3,
          name: 'Experiment tracking',
          summary: 'Compare runs, document decisions, and learn from failures.',
          content: 'Every change to data, model, or hyperparameters should be traceable. Clear experiment notes let teams repeat wins and diagnose weak results.',
          examples: ['Baseline notebook', 'Hyperparameter sweep', 'Best-run report'],
          visualAid: { title: 'Experiment stack', labels: ['Baseline', 'Variant A', 'Variant B', 'Best run'], values: [58, 66, 72, 84] }
        }
      ]
    },
    {
      id: 3,
      title: 'Model Thinking Lab',
      description: 'Compare common algorithms and learn when each one is a strong choice.',
      level: 'Intermediate',
      duration: '3 weeks',
      image: 'sitemap',
      modules: [
        {
          id: 1,
          name: 'Linear and logistic models',
          summary: 'Use simple, explainable models as strong baselines.',
          content: 'Linear regression estimates continuous values. Logistic regression predicts class probabilities. Both are fast, interpretable, and surprisingly competitive on structured data.',
          examples: ['Price prediction', 'Churn probability', 'Click-through rate'],
          visualAid: { title: 'Baseline strength', labels: ['Speed', 'Interpretability', 'Accuracy', 'Scalability'], values: [92, 95, 70, 88] }
        },
        {
          id: 2,
          name: 'Tree models and ensembles',
          summary: 'Capture non-linear patterns without heavy preprocessing.',
          content: 'Decision trees split data into regions. Random forests and gradient boosting combine many trees to improve stability and performance.',
          examples: ['Loan approval', 'Fraud review', 'Demand forecasting'],
          visualAid: { title: 'Tree benefits', labels: ['Flexibility', 'Non-linearity', 'Speed', 'Robustness'], values: [84, 90, 70, 83] }
        },
        {
          id: 3,
          name: 'Model selection strategy',
          summary: 'Choose models based on data shape, latency, and business needs.',
          content: 'The best model is not always the most complex one. Choose based on the problem type, data size, explainability needs, and deployment constraints.',
          examples: ['Edge device classifier', 'Explainable risk score', 'Prototype vision model'],
          visualAid: { title: 'Selection criteria', labels: ['Accuracy', 'Cost', 'Explainability', 'Latency'], values: [88, 76, 81, 79] }
        }
      ]
    },
    {
      id: 4,
      title: 'Neural Network Playground Theory',
      description: 'Learn the structure of neural networks and how training actually changes behavior over time.',
      level: 'Intermediate',
      duration: '4 weeks',
      image: 'project-diagram',
      modules: [
        {
          id: 1,
          name: 'Layers, neurons, and activations',
          summary: 'Build intuition for hidden representations.',
          content: 'Neural networks stack transformations. Hidden layers learn intermediate representations, and activation functions add the non-linearity needed for complex patterns.',
          examples: ['ReLU layers', 'Image features', 'Probability outputs'],
          visualAid: { title: 'Layer flow', labels: ['Input', 'Hidden 1', 'Hidden 2', 'Output'], values: [100, 72, 64, 48] }
        },
        {
          id: 2,
          name: 'Loss and backpropagation',
          summary: 'See how the network learns from errors.',
          content: 'Loss functions measure mistakes. Backpropagation calculates how much each weight contributed to the error so optimizers can improve the network step by step.',
          examples: ['Gradient descent', 'Cross-entropy loss', 'Weight updates'],
          visualAid: { title: 'Training cycle', labels: ['Forward pass', 'Loss', 'Gradients', 'Update'], values: [85, 90, 76, 82] }
        },
        {
          id: 3,
          name: 'Regularization and tuning',
          summary: 'Balance fit, stability, and generalization.',
          content: 'Learning rate, epochs, dropout, and batch size all shape the training process. Careful tuning improves performance without creating brittle models.',
          examples: ['Dropout regularization', 'Early stopping', 'Learning rate decay'],
          visualAid: { title: 'Tuning levers', labels: ['Learning rate', 'Epochs', 'Dropout', 'Batch size'], values: [75, 70, 64, 68] }
        }
      ]
    },
    {
      id: 5,
      title: 'Vision and NLP Applications',
      description: 'Explore how images and language are represented, classified, and evaluated in modern AI products.',
      level: 'Advanced',
      duration: '4 weeks',
      image: 'eye',
      modules: [
        {
          id: 1,
          name: 'Image classification basics',
          summary: 'From pixels to predictions.',
          content: 'Image models learn spatial patterns like edges, shapes, and textures. Convolutional layers help the network notice reusable visual features.',
          examples: ['Cat vs dog classifier', 'Plant disease detection', 'Quality inspection'],
          visualAid: { title: 'Vision pipeline', labels: ['Pixels', 'Features', 'Classifier', 'Label'], values: [100, 72, 61, 45] }
        },
        {
          id: 2,
          name: 'Text embeddings and context',
          summary: 'Convert words and sentences into useful vectors.',
          content: 'Language models map tokens into vector spaces so semantic similarity and context can be learned. Embeddings make search, clustering, and classification stronger.',
          examples: ['Sentence similarity', 'Intent detection', 'Support ticket routing'],
          visualAid: { title: 'Text stack', labels: ['Tokens', 'Embedding', 'Context', 'Intent'], values: [95, 76, 68, 58] }
        },
        {
          id: 3,
          name: 'Responsible deployment',
          summary: 'Design for safety, fairness, and observability.',
          content: 'Production AI needs monitoring, feedback loops, and guardrails. Teams should evaluate edge cases, failures, and fairness risks before shipping.',
          examples: ['Human review', 'Bias checks', 'Model drift alerts'],
          visualAid: { title: 'Risk controls', labels: ['Fairness', 'Monitoring', 'Fallbacks', 'Review'], values: [74, 82, 70, 86] }
        }
      ]
    },
    {
      id: 6,
      title: 'Capstone Launchpad',
      description: 'Tie the course together with project framing, debugging habits, and presentation-ready results.',
      level: 'Advanced',
      duration: '2 weeks',
      image: 'rocket',
      modules: [
        {
          id: 1,
          name: 'Problem framing and success metrics',
          summary: 'Define the task, the metric, and the expected user impact.',
          content: 'Before touching code, define the business question, the metric that matters, and the baseline outcome the project should beat.',
          examples: ['Reduce spam false positives', 'Improve support routing', 'Boost inspection speed'],
          visualAid: { title: 'Project triangle', labels: ['Impact', 'Metric', 'Data', 'Delivery'], values: [88, 80, 76, 70] }
        },
        {
          id: 2,
          name: 'Debugging and iteration loops',
          summary: 'Diagnose weak spots fast.',
          content: 'Most project progress comes from spotting failure patterns. Slice results by segment, inspect confusion patterns, and tighten your data pipeline before switching models.',
          examples: ['Confusion matrix review', 'Segment analysis', 'Label audit'],
          visualAid: { title: 'Debug loop', labels: ['Inspect', 'Hypothesize', 'Test', 'Document'], values: [90, 78, 84, 66] }
        },
        {
          id: 3,
          name: 'Project storytelling',
          summary: 'Present the model clearly to judges and teammates.',
          content: 'Good project demos connect the problem, data, approach, metrics, and next steps into one clear story. Explain tradeoffs, not just wins.',
          examples: ['Demo narrative', 'Metric summary slide', 'Future roadmap'],
          visualAid: { title: 'Demo story', labels: ['Problem', 'Approach', 'Results', 'Next'], values: [88, 82, 86, 72] }
        }
      ]
    }
  ];
}

function getQuizData() {
  return [
    {
      id: 1,
      title: 'Foundations Checkpoint',
      courseId: 1,
      difficulty: 'Beginner',
      successFeedback: 'Strong foundation. You are ready for the next level.',
      retryFeedback: 'Review the module cards and retry with focus on labels, metrics, and data splits.',
      questions: [
        { id: 1, type: 'mcq', prompt: 'Which task is supervised learning?', options: ['Grouping customers by similarity', 'Predicting whether an email is spam', 'Reducing image size without labels', 'Finding unknown clusters'], correct: 1 },
        { id: 2, type: 'mcq', prompt: 'What does overfitting usually mean?', options: ['The model is too small', 'The model memorizes training data and fails on new data', 'The dataset is shuffled', 'The learning rate is zero'], correct: 1 },
        { id: 3, type: 'code', prompt: 'Write one line explaining why we need a test set.', expectedKeywords: ['unseen', 'data'] }
      ]
    },
    {
      id: 2,
      title: 'Workflow and Data Prep',
      courseId: 2,
      difficulty: 'Beginner',
      successFeedback: 'Your workflow instincts are improving.',
      retryFeedback: 'Focus on data cleaning and experiment discipline before retrying.',
      questions: [
        { id: 1, type: 'mcq', prompt: 'Which step should happen before model training?', options: ['Ignoring missing values', 'Cleaning and preparing data', 'Deploying the model', 'Publishing the dashboard'], correct: 1 },
        { id: 2, type: 'code', prompt: 'Type a short preprocessing step that mentions scaling or encoding.', expectedKeywords: ['scale'] },
        { id: 3, type: 'mcq', prompt: 'Why track experiments?', options: ['To delete old runs', 'To compare changes and reproduce the best result', 'To avoid validation', 'To hide failed attempts'], correct: 1 }
      ]
    },
    {
      id: 3,
      title: 'Model Selection Drill',
      courseId: 3,
      difficulty: 'Intermediate',
      successFeedback: 'You are choosing models with better reasoning.',
      retryFeedback: 'Review the tradeoffs between simple baselines and complex models.',
      questions: [
        { id: 1, type: 'mcq', prompt: 'Which model is often a strong baseline for binary classification?', options: ['K-means', 'Logistic regression', 'PCA', 'Apriori'], correct: 1 },
        { id: 2, type: 'mcq', prompt: 'Why are tree ensembles popular on tabular data?', options: ['They only work on images', 'They capture non-linear patterns well', 'They remove the need for testing', 'They always have zero latency'], correct: 1 },
        { id: 3, type: 'code', prompt: 'Describe one reason you might prefer a simple model.', expectedKeywords: ['explain'] }
      ]
    },
    {
      id: 4,
      title: 'Neural Network Tuning Quiz',
      courseId: 4,
      difficulty: 'Intermediate',
      successFeedback: 'Your training intuition is becoming more practical.',
      retryFeedback: 'Revisit learning rate, loss, and regularization before another attempt.',
      questions: [
        { id: 1, type: 'mcq', prompt: 'What does backpropagation compute?', options: ['Random predictions', 'Gradients used to update weights', 'Cluster centers', 'Data labels'], correct: 1 },
        { id: 2, type: 'mcq', prompt: 'A very high learning rate often causes what?', options: ['Stable convergence', 'No gradients', 'Training instability', 'Automatic regularization'], correct: 2 },
        { id: 3, type: 'code', prompt: 'Type one tuning lever you would change to reduce overfitting.', expectedKeywords: ['dropout'] }
      ]
    },
    {
      id: 5,
      title: 'Vision and NLP Readiness',
      courseId: 5,
      difficulty: 'Advanced',
      successFeedback: 'You are thinking beyond the model into real-world deployment.',
      retryFeedback: 'Review embeddings, convolution, and responsible release practices.',
      questions: [
        { id: 1, type: 'mcq', prompt: 'What do embeddings help with in NLP?', options: ['Deleting tokens', 'Representing meaning in vector form', 'Avoiding all preprocessing', 'Drawing confusion matrices'], correct: 1 },
        { id: 2, type: 'mcq', prompt: 'Why are guardrails important in production AI?', options: ['They increase font size', 'They reduce monitoring needs', 'They help manage risk and failures', 'They remove the need for evaluation'], correct: 2 },
        { id: 3, type: 'code', prompt: 'Name one production safety practice for AI systems.', expectedKeywords: ['monitor'] }
      ]
    },
    {
      id: 6,
      title: 'Capstone Reflection Quiz',
      courseId: 6,
      difficulty: 'Advanced',
      successFeedback: 'You are ready to pitch and ship a thoughtful demo.',
      retryFeedback: 'Focus on project framing, metrics, and storytelling clarity.',
      questions: [
        { id: 1, type: 'mcq', prompt: 'What should come first in a project kickoff?', options: ['Choosing the fanciest model', 'Defining the problem and success metric', 'Designing badges', 'Publishing a leaderboard'], correct: 1 },
        { id: 2, type: 'code', prompt: 'Write one word that belongs in a strong demo narrative.', expectedKeywords: ['results'] },
        { id: 3, type: 'mcq', prompt: 'Which habit improves project iteration most?', options: ['Skipping baseline models', 'Inspecting failure patterns and documenting changes', 'Avoiding confusion matrices', 'Hiding weak results'], correct: 1 }
      ]
    }
  ];
}

function getGameData() {
  return [
    { id: 1, name: 'Decision Split Sprint', description: 'Pick the best feature split across a series of mini tree challenges.', image: 'code-branch', category: 'Decision Trees', goal: 'Maximize information gain across three rounds.' },
    { id: 2, name: 'Classification Sorter', description: 'Sort examples into the correct class before the queue fills up.', image: 'filter', category: 'Classification', goal: 'Classify all cards with high accuracy.' },
    { id: 3, name: 'Neural Network Tuner', description: 'Adjust learning rate, epochs, and regularization to reach a healthy model balance.', image: 'wave-square', category: 'Neural Networks', goal: 'Hit strong validation accuracy without overfitting.' }
  ];
}

function getSimulationData() {
  return [
    {
      id: 1,
      title: 'Spam Detection Studio',
      category: 'Real-world simulation',
      dataset: 'messages-mini.csv',
      description: 'Explore labeled messages, engineer useful features, and improve spam recall without flooding users with false alarms.',
      steps: ['Inspect the class balance and sample messages.', 'Pick features such as suspicious keywords, sender history, and punctuation density.', 'Compare baseline logistic regression with a tree model.', 'Review a confusion matrix and tune for safer precision-recall balance.'],
      sampleMetrics: [{ label: 'Precision', value: '0.91' }, { label: 'Recall', value: '0.86' }, { label: 'F1 score', value: '0.88' }]
    },
    {
      id: 2,
      title: 'Image Classification Demo',
      category: 'Vision simulation',
      dataset: 'tiny-vision-set.zip',
      description: 'Walk through a small image pipeline with class folders, augmentation ideas, and prediction feedback.',
      steps: ['Preview a few image samples per class.', 'Discuss augmentation and train-validation split choices.', 'Choose a lightweight CNN baseline.', 'Interpret prediction confidence and next-step improvements.'],
      sampleMetrics: [{ label: 'Top-1 accuracy', value: '0.84' }, { label: 'Validation loss', value: '0.42' }, { label: 'Inference time', value: '38ms' }]
    }
  ];
}

initializeDataFiles();

app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Something went wrong.' });
});

app.use((req, res) => {
  res.status(404).json({ error: 'Route not found.' });
});

app.listen(PORT, () => {
  console.log(`AIML platform running on http://localhost:${PORT}`);
});
