# 🚀 Deployment & Testing Guide

## Local Testing

### Starting the Platform Locally

1. **Open PowerShell or Command Prompt**
```powershell
cd d:\xampp\htdocs\vibethon\backend
npm install
npm start
```

2. **Open Browser**
   - Navigate to: `http://localhost:5000`
   - You should see the AIML Learning Platform homepage

3. **Test Features**
   - ✅ Sign up with test email
   - ✅ Take a quiz
   - ✅ Play a game
   - ✅ Check dashboard

---

## Feature Testing Checklist

### Authentication ✅
- [ ] Sign up with unique email
- [ ] Login with registered email
- [ ] User data persists in browser
- [ ] Logout clears user session
- [ ] Cannot login without signup

### Courses ✅
- [ ] All 4 courses display
- [ ] Course details modal opens
- [ ] Modules show correctly
- [ ] Complete module checkbox works
- [ ] Points awarded on module complete

### Quizzes ✅
- [ ] All quizzes display
- [ ] Quiz modal opens
- [ ] Questions display properly
- [ ] Options are selectable
- [ ] Navigation between questions works
- [ ] Score calculation is correct
- [ ] Results review shows feedback
- [ ] Points awarded to user

### Games ✅
- [ ] Decision Tree Builder loads
- [ ] Neural Network Trainer loads
- [ ] Clustering Quest loads
- [ ] Game visualizations render
- [ ] Scoring system works
- [ ] Points added to user account

### Dashboard ✅
- [ ] User profile displays correctly
- [ ] Statistics update after actions
- [ ] Badges appear for achievements
- [ ] Progress bars show correct %
- [ ] Leaderboard displays
- [ ] Level bar fills correctly

### Code Practice ✅
- [ ] Code editor loads
- [ ] Sample code displays
- [ ] Code execution works
- [ ] Output displays
- [ ] Points awarded

### Responsive Design ✅
- [ ] Desktop layout works (1920x1080)
- [ ] Tablet layout works (768x1024)
- [ ] Mobile layout works (375x667)
- [ ] All buttons clickable on mobile
- [ ] Navigation works on all sizes
- [ ] No horizontal scrolling on mobile

### UI/UX ✅
- [ ] Smooth animations
- [ ] Hover effects work
- [ ] Colors contrast well
- [ ] Text is readable
- [ ] Buttons are accessible
- [ ] Modal close works
- [ ] Notifications appear

---

## Performance Testing

### Load Testing
```
Expected Performance:
- Homepage load: < 1 second
- Quiz display: < 500ms
- Game render: < 1 second
- Quiz submission: < 2 seconds
- Dashboard update: < 1 second
```

### Browser Compatibility
- ✅ Chrome (Recommended)
- ✅ Firefox
- ✅ Safari
- ✅ Edge
- ✅ Mobile browsers

### Network Conditions
- ✅ Works online
- ✅ Resources cached for offline
- ✅ Graceful degradation

---

## Security Testing

### Input Validation
- [ ] XSS prevention (special characters handled)
- [ ] HTML injection prevented
- [ ] File upload security (if implemented)
- [ ] SQL injection impossible (JSON storage)

### Data Privacy
- [ ] No sensitive data in browser storage
- [ ] No passwords stored
- [ ] CORS properly configured
- [ ] User data not logged unnecessarily

---

## Database Migration Testing

### Upgrading from JSON to MongoDB

1. **Install MongoDB**: https://www.mongodb.com/try/download/community

2. **Update server.js** to connect to MongoDB:
```javascript
// Instead of JSON file storage
const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/aiml-platform');
```

3. **Create Mongoose Models**:
```javascript
// models/User.js
const userSchema = new Schema({
  name: String,
  email: { type: String, unique: true },
  points: { type: Number, default: 0 },
  level: { type: Number, default: 1 },
  badges: [String],
  progress: Schema.Types.Mixed,
  createdAt: { type: Date, default: Date.now }
});
```

4. **Migrate Data**:
```javascript
// Migrate existing JSON to MongoDB
const users = JSON.parse(fs.readFileSync('data/users.json'));
await User.insertMany(users);
```

---

## Deployment Options

### Option 1: Heroku (Free Tier)

1. **Create Heroku account**: https://heroku.com

2. **Install Heroku CLI**

3. **Deploy**:
```bash
heroku login
heroku create your-app-name
git push heroku main
```

### Option 2: AWS (EC2)

1. **Launch EC2 instance** (Ubuntu)

2. **SSH into instance**

3. **Install Node.js**:
```bash
sudo apt update
sudo apt install nodejs npm
```

4. **Deploy app**:
```bash
git clone [repo-url]
cd vibethon/backend
npm install
npm start
```

### Option 3: DigitalOcean

1. **Create Droplet** (Ubuntu)

2. **SSH and install Node.js**

3. **Use PM2** to run app:
```bash
npm install -g pm2
pm2 start server.js
pm2 startup
pm2 save
```

### Option 4: Vercel (Frontend Only)

1. **Push to GitHub**

2. **Connect Vercel**

3. **Deploy frontend**

4. **Set backend API URL** in environment variables

---

## Docker Deployment

### Dockerfile
```dockerfile
FROM node:16-alpine

WORKDIR /app

COPY package*.json ./
RUN npm install

COPY . .

EXPOSE 5000

CMD ["npm", "start"]
```

### Build & Run
```bash
docker build -t aiml-platform .
docker run -p 5000:5000 aiml-platform
```

---

## SSL/HTTPS Setup

### Using Let's Encrypt (Free)

1. **Install Certbot**
2. **Generate Certificate**:
```bash
certbot certonly --standalone -d yourdomain.com
```

3. **Update server.js**:
```javascript
const https = require('https');
const fs = require('fs');

const options = {
  key: fs.readFileSync('/path/to/private.key'),
  cert: fs.readFileSync('/path/to/certificate.crt')
};

https.createServer(options, app).listen(443);
```

---

## Monitoring & Logging

### PM2 Monitoring
```bash
pm2 install pm2-auto-pull
pm2 monitor
```

### Log Files
```bash
pm2 logs aiml-platform
pm2 logs aiml-platform --lines 100
```

### Analytics Integration (Future)
- Google Analytics
- Mixpanel
- Custom Event Tracking

---

## Backup & Recovery

### Backup JSON Data
```bash
# Backup script
cp -r backend/data backend/data.backup.$(date +%Y%m%d)
```

### Automated Backup (Future)
- Use MongoDB Atlas for cloud backup
- Implement incremental backups
- Set 7-day retention policy

---

## Performance Optimization

### Implemented Optimizations
- ✅ Minified CSS
- ✅ No external CDN dependencies
- ✅ Local image storage
- ✅ Lazy loading support
- ✅ Browser caching

### Future Optimizations
- [ ] Webpack bundling
- [ ] Code splitting
- [ ] Service worker
- [ ] Compression (gzip)
- [ ] CDN for static assets
- [ ] Database indexing
- [ ] Query optimization
- [ ] Caching layer (Redis)

---

## Scaling Strategy

### Current Setup
- Single server
- JSON file storage
- In-memory sessions
- Suitable for: 100-500 concurrent users

### Medium Scale (5,000+ users)
- MongoDB database
- Redis session store
- Load balancer (Nginx)
- Separate API server

### Large Scale (50,000+ users)
- Database replication
- Message queue (RabbitMQ)
- Microservices
- CDN distribution
- Multiple API servers

---

## Maintenance & Updates

### Regular Tasks
- [ ] Weekly: Check error logs
- [ ] Weekly: Review user feedback
- [ ] Monthly: Update dependencies
- [ ] Monthly: Review analytics
- [ ] Quarterly: Security audit
- [ ] Quarterly: Performance review

### Dependencies Update
```bash
npm outdated           # Check for updates
npm update            # Update all packages
npm audit            # Check security
npm audit fix        # Fix vulnerabilities
```

---

## Disaster Recovery Plan

### Backup Strategy
1. Daily automated backups to S3
2. Weekly full backup archive
3. 30-day retention policy
4. Test recovery monthly

### Recovery Steps
1. Stop current application
2. Restore from latest backup
3. Verify data integrity
4. Restart services
5. Monitor for issues

---

## Support & Troubleshooting

### Common Issues

**Issue**: Port 5000 already in use
```bash
# Find process using port
netstat -ano | findstr :5000

# Kill process
taskkill /PID [PID] /F
```

**Issue**: Module not found
```bash
rm -rf node_modules
npm install
```

**Issue**: CORS errors
- Check CORS configuration in server.js
- Verify frontend and backend URLs match

**Issue**: Data not persisting
- Check browser localStorage settings
- Verify JSON files are readable
- Check file permissions

---

## Testing Automation (Future)

### Unit Tests
```bash
npm test
```

### Integration Tests
```javascript
// Test quiz submission
describe('Quiz API', () => {
  it('should submit quiz and return score', async () => {
    const response = await fetch('/api/quizzes/1/submit', {...});
    expect(response.status).toBe(200);
  });
});
```

### E2E Tests (Cypress)
```javascript
describe('User Journey', () => {
  it('should complete full learning flow', () => {
    cy.visit('/');
    cy.click('Sign Up');
    cy.fillForm(...);
    cy.takeQuiz();
    cy.checkDashboard();
  });
});
```

---

## Continuous Integration/Deployment

### GitHub Actions
```yaml
name: CI/CD
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - run: npm install
      - run: npm test
      - run: deploy
```

---

## Version Control

### Branch Strategy
- `main`: Production-ready code
- `develop`: Development branch
- `feature/*`: Feature branches
- `bugfix/*`: Bug fix branches

### Commit Messages
```
[FEATURE] Add new quiz system
[BUGFIX] Fix modal close issue
[DOCS] Update README
[PERF] Optimize game rendering
```

---

## Documentation Updates

Update when:
- Adding new features
- Changing API endpoints
- Modifying deployment process
- Discovering new issues/solutions

---

**Deployment Checklist**
- [ ] All tests passing
- [ ] Documentation updated
- [ ] Security audit passed
- [ ] Performance acceptable
- [ ] Backups configured
- [ ] Monitoring set up
- [ ] Team trained
- [ ] Rollback plan ready

Ready to deploy! 🚀
