const GameHub = (() => {
  const state = {
    game: null,
    user: null,
    onSaved: null,
    notify: null,
    decisionRound: 0,
    decisionScore: 0,
    sortIndex: 0,
    sortScore: 0,
    tuning: { lr: 0.2, epochs: 6, regularization: 0.3, validation: 58, train: 64 }
  };

  const decisionPrompts = [
    {
      scenario: 'You want to separate loan approvals. Which feature creates the cleanest first split?',
      choices: [
        { label: 'Credit score', gain: 0.84, best: true },
        { label: 'Favorite color', gain: 0.04, best: false },
        { label: 'Office floor', gain: 0.16, best: false }
      ]
    },
    {
      scenario: 'You are splitting a churn dataset. Which feature gives the strongest separation?',
      choices: [
        { label: 'Monthly support tickets', gain: 0.65, best: true },
        { label: 'Coffee order', gain: 0.03, best: false },
        { label: 'Desk orientation', gain: 0.07, best: false }
      ]
    },
    {
      scenario: 'For spam filtering, which feature is the best next split?',
      choices: [
        { label: 'Contains suspicious keywords', gain: 0.91, best: true },
        { label: 'Email font size', gain: 0.12, best: false },
        { label: 'Inbox folder color', gain: 0.02, best: false }
      ]
    }
  ];

  const sortQueue = [
    { label: 'FREE prize now', correct: 'spam' },
    { label: 'Project meeting moved to 4 PM', correct: 'safe' },
    { label: 'Claim bonus cash today', correct: 'spam' },
    { label: 'Lunch plan for tomorrow?', correct: 'safe' },
    { label: 'Urgent invoice attached', correct: 'spam' }
  ];

  function openGame(game, user, onSaved, notify) {
    state.game = game;
    state.user = user;
    state.onSaved = onSaved;
    state.notify = notify;

    if (game.id === 1) {
      state.decisionRound = 0;
      state.decisionScore = 0;
      renderDecisionGame();
      return;
    }

    if (game.id === 2) {
      state.sortIndex = 0;
      state.sortScore = 0;
      renderSortGame();
      return;
    }

    state.tuning = { lr: 0.2, epochs: 6, regularization: 0.3, validation: 58, train: 64 };
    renderTuningGame();
  }

  function mount(html) {
    document.getElementById('gameDetail').innerHTML = html;
  }

  function renderDecisionGame() {
    const prompt = decisionPrompts[state.decisionRound];
    if (!prompt) {
      finishGame(1, state.decisionScore, 'Tree Tactician');
      return;
    }

    mount(`
      <div class="game-shell">
        <div class="card-top">
          <div>
            <div class="tag">Decision Trees</div>
            <h2>Decision Split Sprint</h2>
          </div>
          <div class="metric-chip">Round ${state.decisionRound + 1}/${decisionPrompts.length}</div>
        </div>
        <div class="small-visual">
          <strong>Small tree preview</strong>
          <div class="visual-chart">
            <div class="visual-bar"><span>Root uncertainty</span><i style="width:${70 - state.decisionRound * 12}%"></i></div>
            <div class="visual-bar"><span>Current clarity</span><i style="width:${42 + state.decisionScore}%"></i></div>
          </div>
        </div>
        <div class="game-stage">
          <p>${prompt.scenario}</p>
          <div class="stack-list">
            ${prompt.choices.map((choice, index) => `
              <button class="choice-btn" onclick="GameHub.pickDecision(${index})">${choice.label} <small>Gain ${choice.gain}</small></button>
            `).join('')}
          </div>
          <div class="card-meta"><span class="metric-chip">Score ${state.decisionScore}</span></div>
        </div>
      </div>
    `);
  }

  function pickDecision(index) {
    const choice = decisionPrompts[state.decisionRound].choices[index];
    state.decisionScore += choice.best ? 35 : 10;
    state.notify(choice.best ? 'Best split selected.' : 'That split works, but there is a cleaner option.', choice.best ? '' : 'error');
    state.decisionRound += 1;
    renderDecisionGame();
  }

  function renderSortGame() {
    const card = sortQueue[state.sortIndex];
    if (!card) {
      finishGame(2, state.sortScore, 'Classifier Ace');
      return;
    }

    const progress = Math.round((state.sortIndex / sortQueue.length) * 100);
    mount(`
      <div class="game-shell">
        <div class="card-top">
          <div>
            <div class="tag">Classification</div>
            <h2>Classification Sorter</h2>
          </div>
          <div class="metric-chip">${state.sortIndex + 1}/${sortQueue.length}</div>
        </div>
        <div class="game-stage">
          <div class="game-meter"><span style="width:${progress}%"></span></div>
          <div class="small-visual">
            <strong>Incoming sample</strong>
            <p>${card.label}</p>
          </div>
          <div class="card-actions">
            <button class="btn btn-primary" onclick="GameHub.sortCard('spam')">Mark as spam</button>
            <button class="btn btn-secondary" onclick="GameHub.sortCard('safe')">Mark as safe</button>
          </div>
          <div class="card-meta"><span class="metric-chip">Score ${state.sortScore}</span></div>
        </div>
      </div>
    `);
  }

  function sortCard(label) {
    const card = sortQueue[state.sortIndex];
    const correct = card.correct === label;
    state.sortScore += correct ? 25 : 5;
    state.notify(correct ? 'Correct classification.' : 'Close, but this sample belongs in the other class.', correct ? '' : 'error');
    state.sortIndex += 1;
    renderSortGame();
  }

  function renderTuningGame() {
    updateTuningMetrics();
    mount(`
      <div class="game-shell">
        <div class="card-top">
          <div>
            <div class="tag">Neural Networks</div>
            <h2>Neural Network Tuner</h2>
          </div>
          <div class="metric-chip">Tune for healthy validation</div>
        </div>
        <div class="small-visual">
          <strong>Compact model visual</strong>
          <div class="visual-chart">
            <div class="visual-bar"><span>Train accuracy</span><i style="width:${state.tuning.train}%"></i></div>
            <div class="visual-bar"><span>Validation accuracy</span><i style="width:${state.tuning.validation}%"></i></div>
          </div>
        </div>
        <div class="game-stage">
          <div class="stack-list">
            <label class="tuning-chip active">Learning rate: ${state.tuning.lr.toFixed(2)}
              <input type="range" min="0.05" max="1" step="0.05" value="${state.tuning.lr}" oninput="GameHub.updateTuning('lr', this.value)">
            </label>
            <label class="tuning-chip active">Epochs: ${state.tuning.epochs}
              <input type="range" min="2" max="20" step="1" value="${state.tuning.epochs}" oninput="GameHub.updateTuning('epochs', this.value)">
            </label>
            <label class="tuning-chip active">Regularization: ${state.tuning.regularization.toFixed(2)}
              <input type="range" min="0.05" max="1" step="0.05" value="${state.tuning.regularization}" oninput="GameHub.updateTuning('regularization', this.value)">
            </label>
          </div>
          <div class="card-meta">
            <span class="metric-chip">Train ${state.tuning.train}%</span>
            <span class="metric-chip">Validation ${state.tuning.validation}%</span>
            <span class="metric-chip">Gap ${Math.abs(state.tuning.train - state.tuning.validation)}%</span>
          </div>
          <div class="card-actions">
            <button class="btn btn-primary" onclick="GameHub.finishTuning()">Lock this setup</button>
            <button class="btn btn-secondary" onclick="GameHub.resetTuning()">Reset</button>
          </div>
        </div>
      </div>
    `);
  }

  function updateTuning(key, value) {
    state.tuning[key] = key === 'epochs' ? Number(value) : Number(value);
    renderTuningGame();
  }

  function updateTuningMetrics() {
    const lrPenalty = Math.abs(state.tuning.lr - 0.45) * 42;
    const epochPenalty = Math.abs(state.tuning.epochs - 11) * 1.9;
    const regPenalty = Math.abs(state.tuning.regularization - 0.35) * 38;
    const train = Math.max(62, Math.min(97, Math.round(92 - regPenalty / 3 - lrPenalty / 8 + state.tuning.epochs)));
    const validation = Math.max(55, Math.min(95, Math.round(90 - lrPenalty - epochPenalty - regPenalty)));
    state.tuning.train = train;
    state.tuning.validation = validation;
  }

  function finishTuning() {
    const gap = Math.abs(state.tuning.train - state.tuning.validation);
    const score = Math.max(35, state.tuning.validation - gap);
    finishGame(3, score, gap <= 8 && state.tuning.validation >= 78 ? 'Tuning Wizard' : '');
  }

  function resetTuning() {
    state.tuning = { lr: 0.2, epochs: 6, regularization: 0.3, validation: 58, train: 64 };
    renderTuningGame();
  }

  async function finishGame(gameId, score, achievement) {
    const requiresLogin = !state.user;
    mount(`
      <div class="game-shell">
        <div class="card-top">
          <div>
            <div class="tag">Game complete</div>
            <h2>${state.game.name}</h2>
          </div>
          <div class="metric-chip">Score ${score}</div>
        </div>
        <div class="module-grid">
          <p>${achievement ? `Achievement unlocked: ${achievement}.` : 'Nice run. Replay to push the score higher.'}</p>
          <div class="card-actions">
            <button class="btn btn-primary" onclick="GameHub.replay()">Play again</button>
          </div>
          <small>${requiresLogin ? 'Login to save this score to the leaderboard and dashboard.' : 'Your score is being saved to the dashboard.'}</small>
        </div>
      </div>
    `);

    if (requiresLogin) {
      state.notify('Login to save your game score.', 'error');
      return;
    }

    try {
      const result = await window.apiFetch(`/games/${gameId}/score`, {
        method: 'POST',
        body: JSON.stringify({
          userEmail: state.user.email,
          score,
          title: state.game.name,
          achievement
        })
      });
      state.notify(`Saved ${state.game.name} score ${score}.`);
      if (state.onSaved) {
        await state.onSaved(result.dashboard);
      }
    } catch (error) {
      state.notify(error.message, 'error');
    }
  }

  function replay() {
    openGame(state.game, state.user, state.onSaved, state.notify);
  }

  return {
    openGame,
    pickDecision,
    sortCard,
    updateTuning,
    finishTuning,
    resetTuning,
    replay
  };
})();

window.GameHub = GameHub;
