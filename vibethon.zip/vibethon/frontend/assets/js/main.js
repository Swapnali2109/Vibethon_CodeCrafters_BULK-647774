const API_URL = 'http://localhost:5000/api';

const state = {
  user: null,
  courses: [],
  quizzes: [],
  games: [],
  simulations: [],
  questions: [],
  classrooms: [],
  currentClassroom: null,
  leaderboard: [],
  dashboard: null
};

const iconMap = {
  brain: 'fa-brain',
  database: 'fa-database',
  sitemap: 'fa-sitemap',
  'project-diagram': 'fa-project-diagram',
  eye: 'fa-eye',
  rocket: 'fa-rocket',
  'code-branch': 'fa-code-branch',
  filter: 'fa-filter',
  'wave-square': 'fa-wave-square'
};

const codeSnippets = {
  python: `# Mini ML playground\nimport math\n\nmessages = ['buy now', 'hello friend', 'free prize']\nspam_words = {'buy', 'free', 'prize'}\n\ndef spam_score(text):\n    return sum(word in spam_words for word in text.split())\n\nfor message in messages:\n    print(message, spam_score(message))`,
  javascript: `// Tiny neural activation demo\nconst inputs = [0.2, 0.8, -0.1];\nconst weights = [0.5, 0.9, 0.3];\nconst score = inputs.reduce((sum, value, index) => sum + value * weights[index], 0);\nconst relu = Math.max(0, score);\nconsole.log({ score, relu });`
};

document.addEventListener('DOMContentLoaded', async () => {
  bindEvents();
  loadUserFromStorage();
  await Promise.all([loadCourses(), loadQuizzes(), loadGames(), loadSimulations(), loadLeaderboard(), loadQuestions(), loadClassrooms()]);
  initializePlayground();
  await refreshDashboard();
});

function bindEvents() {
  document.getElementById('authButton').addEventListener('click', () => {
    if (state.user) {
      logout();
      return;
    }
    openModal('authModal');
  });

  document.getElementById('heroStartBtn').addEventListener('click', () => openModal('authModal'));
  document.getElementById('loginForm').addEventListener('submit', handleLogin);
  document.getElementById('signupForm').addEventListener('submit', handleSignup);
  document.getElementById('languageSelect').addEventListener('change', (event) => {
    document.getElementById('codeEditor').value = codeSnippets[event.target.value];
  });
  document.getElementById('runCodeBtn').addEventListener('click', runCode);
  document.getElementById('tutorSendBtn').addEventListener('click', askQuestion);
  document.getElementById('createClassroomBtn').addEventListener('click', createClassroom);
  document.getElementById('joinClassroomBtn').addEventListener('click', joinClassroom);

  document.querySelectorAll('.tab-btn').forEach((button) => {
    button.addEventListener('click', () => toggleAuthTab(button.dataset.tab));
  });

  document.querySelectorAll('[data-close]').forEach((button) => {
    button.addEventListener('click', () => closeModal(button.dataset.close));
  });

  document.querySelectorAll('.modal').forEach((modal) => {
    modal.addEventListener('click', (event) => {
      if (event.target === modal) {
        closeModal(modal.id);
      }
    });
  });

  document.querySelectorAll('[data-provider]').forEach((button) => {
    button.addEventListener('click', () => handleOAuth(button.dataset.provider));
  });
}

function loadUserFromStorage() {
  const stored = localStorage.getItem('aimlCurrentUser');
  if (stored) {
    state.user = JSON.parse(stored);
    updateAuthButton();
  }
}

function saveUserToStorage(user) {
  state.user = user;
  localStorage.setItem('aimlCurrentUser', JSON.stringify(user));
  updateAuthButton();
}

function updateAuthButton() {
  const button = document.getElementById('authButton');
  button.textContent = state.user ? `Logout ${state.user.name.split(' ')[0]}` : 'Sign In';
}

async function apiFetch(path, options = {}) {
  const response = await fetch(`${API_URL}${path}`, {
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.error || 'Request failed');
  }
  return data;
}

async function loadCourses() {
  state.courses = await apiFetch('/courses');
  renderCourses();
}

async function loadQuizzes() {
  state.quizzes = await apiFetch('/quizzes');
  renderQuizzes();
}

async function loadGames() {
  state.games = await apiFetch('/games');
  renderGames();
}

async function loadSimulations() {
  state.simulations = await apiFetch('/simulations');
  renderSimulations();
}

async function loadLeaderboard() {
  state.leaderboard = await apiFetch('/leaderboard');
  renderLeaderboard(state.leaderboard);
}

async function loadQuestions() {
  state.questions = await apiFetch('/questions');
  renderQuestions();
}

async function loadClassrooms() {
  state.classrooms = await apiFetch('/classrooms');
  renderClassrooms();
}

async function refreshDashboard() {
  if (!state.user) {
    state.dashboard = null;
    renderGuestDashboard();
    await loadLeaderboard();
    return;
  }

  try {
    state.dashboard = await apiFetch(`/users/${encodeURIComponent(state.user.email)}/dashboard`);
    state.user = state.dashboard.user;
    localStorage.setItem('aimlCurrentUser', JSON.stringify(state.user));
    renderDashboard(state.dashboard);
  } catch (error) {
    showToast(error.message, 'error');
  }
}

function renderCourses() {
  const container = document.getElementById('coursesContainer');
  container.innerHTML = state.courses.map((course) => `
    <article class="course-card">
      <div class="card-top">
        <div>
          <div class="tag">${course.level}</div>
          <h3>${course.title}</h3>
        </div>
        <div class="card-icon"><i class="fas ${iconMap[course.image] || 'fa-book-open'}"></i></div>
      </div>
      <div class="card-body">
        <p>${course.description}</p>
        <div class="card-meta">
          <span class="metric-chip">${course.duration}</span>
          <span class="metric-chip">${course.modules.length} modules</span>
        </div>
      </div>
      <div class="card-actions">
        <button class="btn btn-primary" onclick="openCourse(${course.id})">Open path</button>
      </div>
    </article>
  `).join('');
}

function renderQuizzes() {
  const container = document.getElementById('quizzesContainer');
  container.innerHTML = state.quizzes.map((quiz) => `
    <article class="quiz-card">
      <div class="card-top">
        <div>
          <div class="tag">${quiz.difficulty}</div>
          <h3>${quiz.title}</h3>
        </div>
        <div class="card-icon"><i class="fas fa-clipboard-check"></i></div>
      </div>
      <div class="card-body">
        <p>${quiz.questions.length} questions including MCQ and short code explanation prompts.</p>
      </div>
      <div class="card-actions">
        <button class="btn btn-primary" onclick="openQuiz(${quiz.id})">Take quiz</button>
      </div>
    </article>
  `).join('');
}

function renderGames() {
  const container = document.getElementById('gamesContainer');
  container.innerHTML = state.games.map((game) => `
    <article class="game-card">
      <div class="card-top">
        <div>
          <div class="tag">${game.category}</div>
          <h3>${game.name}</h3>
        </div>
        <div class="card-icon"><i class="fas ${iconMap[game.image] || 'fa-gamepad'}"></i></div>
      </div>
      <div class="card-body">
        <p>${game.description}</p>
        <div class="metric-chip">${game.goal}</div>
      </div>
      <div class="card-actions">
        <button class="btn btn-primary" onclick="launchGame(${game.id})">Play now</button>
      </div>
    </article>
  `).join('');
}

function renderSimulations() {
  const container = document.getElementById('simulationsContainer');
  container.innerHTML = state.simulations.map((simulation) => `
    <article class="simulation-card">
      <div class="tag">${simulation.category}</div>
      <h3>${simulation.title}</h3>
      <p>${simulation.description}</p>
      <div class="metric-chip">Dataset: ${simulation.dataset}</div>
      <ol class="simulation-steps">
        ${simulation.steps.map((step) => `<li>${step}</li>`).join('')}
      </ol>
      <div class="simulation-metrics">
        ${simulation.sampleMetrics.map((metric) => `<span class="metric-chip">${metric.label}: ${metric.value}</span>`).join('')}
      </div>
    </article>
  `).join('');
}

function renderQuestions() {
  const container = document.getElementById('tutorMessages');
  if (!container) {
    return;
  }

  if (!state.questions.length) {
    container.innerHTML = '<div class="question-card"><strong>No questions yet</strong><small>Ask your first AIML question to start the discussion.</small></div>';
    return;
  }

  container.innerHTML = state.questions.map((entry) => `
    <div class="question-card">
      <strong>${entry.authorName}</strong>
      <p>${entry.question}</p>
      <small>${entry.answer}</small>
    </div>
  `).join('');
}

function renderClassrooms() {
  const container = document.getElementById('classroomList');
  if (!container) {
    return;
  }

  if (!state.classrooms.length) {
    container.innerHTML = '<div class="classroom-card"><strong>No classrooms yet</strong><small>Create the first classroom to collaborate with others.</small></div>';
    return;
  }

  container.innerHTML = state.classrooms.map((room) => `
    <div class="classroom-card ${state.currentClassroom?.code === room.code ? 'active-classroom' : ''}">
      <strong>${room.name}</strong>
      <small>Code: ${room.code}</small>
      <small>${room.members.length} members</small>
      <button class="btn btn-secondary" onclick="selectClassroom('${room.code}')">View</button>
    </div>
  `).join('');

  updateClassroomStatus();
}

function updateClassroomStatus() {
  const status = document.getElementById('collabRoomStatus');
  if (!status) {
    return;
  }

  if (!state.currentClassroom) {
    status.textContent = 'No classroom selected yet.';
    return;
  }

  const members = state.currentClassroom.members.map((member) => member.name).join(', ');
  status.textContent = `${state.currentClassroom.name} (${state.currentClassroom.code}) - Members: ${members}`;
}

function initializePlayground() {
  document.getElementById('codeEditor').value = codeSnippets.python;
  const presetContainer = document.getElementById('playgroundPresets');
  presetContainer.innerHTML = `
    <button class="preset-chip" onclick="applyPreset('python')">Python spam features</button>
    <button class="preset-chip" onclick="applyPreset('javascript')">JavaScript activation demo</button>
  `;
}

function toggleAuthTab(tabName) {
  document.querySelectorAll('.tab-btn').forEach((button) => button.classList.toggle('active', button.dataset.tab === tabName));
  document.querySelectorAll('.auth-form').forEach((form) => form.classList.toggle('active', form.id === `${tabName}Form`));
}

async function handleLogin(event) {
  event.preventDefault();
  const form = new FormData(event.target);
  try {
    const data = await apiFetch('/users/login', {
      method: 'POST',
      body: JSON.stringify({ email: form.get('email'), password: form.get('password') })
    });
    saveUserToStorage(data.user);
    closeModal('authModal');
    await refreshDashboard();
    showToast('Welcome back. Your progress is loaded.');
  } catch (error) {
    showToast(error.message, 'error');
  }
}

async function handleSignup(event) {
  event.preventDefault();
  const form = new FormData(event.target);
  try {
    const data = await apiFetch('/users/register', {
      method: 'POST',
      body: JSON.stringify({ name: form.get('name'), email: form.get('email'), password: form.get('password') })
    });
    saveUserToStorage(data.user);
    closeModal('authModal');
    await refreshDashboard();
    showToast('Account created. Start your first path.');
  } catch (error) {
    showToast(error.message, 'error');
  }
}

async function handleOAuth(provider) {
  const seed = Date.now().toString().slice(-5);
  try {
    const data = await apiFetch('/users/oauth', {
      method: 'POST',
      body: JSON.stringify({
        provider,
        name: `${provider[0].toUpperCase()}${provider.slice(1)} Learner`,
        email: `${provider}.demo.${seed}@example.com`
      })
    });
    saveUserToStorage(data.user);
    closeModal('authModal');
    await refreshDashboard();
    showToast(`Signed in with ${provider}.`);
  } catch (error) {
    showToast(error.message, 'error');
  }
}

async function logout() {
  try {
    await apiFetch('/users/logout', { method: 'POST', body: JSON.stringify({}) });
  } catch (error) {
    // Ignore demo logout errors.
  }
  state.user = null;
  localStorage.removeItem('aimlCurrentUser');
  updateAuthButton();
  await refreshDashboard();
  showToast('Signed out successfully.');
}
function openCourse(courseId) {
  const course = state.courses.find((item) => item.id === courseId);
  if (!course) {
    return;
  }

  const modules = course.modules.map((module) => {
    const progressKey = `${course.id}-${module.id}`;
    const completed = Boolean(state.user?.progress?.[progressKey]?.completed);
    return `
      <section class="module-grid">
        <div class="card-top">
          <div>
            <div class="tag">Module ${module.id}</div>
            <h3>${module.name}</h3>
          </div>
          <div class="metric-chip">${completed ? 'Completed' : 'In progress'}</div>
        </div>
        <p>${module.summary}</p>
        <p>${module.content}</p>
        <div class="tag-row">${module.examples.map((example) => `<span class="metric-chip">${example}</span>`).join('')}</div>
        <div class="small-visual">
          <strong>${module.visualAid.title}</strong>
          <div class="visual-chart">
            ${module.visualAid.labels.map((label, index) => `
              <div class="visual-bar">
                <span>${label}</span>
                <i style="width:${module.visualAid.values[index]}%"></i>
              </div>
            `).join('')}
          </div>
        </div>
        <div class="card-actions">
          <button class="btn btn-primary" onclick="markModuleComplete(${course.id}, ${module.id}, '${module.name.replace(/'/g, '&#39;')}')">${completed ? 'Completed' : 'Mark complete'}</button>
        </div>
      </section>
    `;
  }).join('');

  document.getElementById('courseDetail').innerHTML = `
    <div class="course-detail-shell">
      <div class="card-top">
        <div>
          <div class="tag">${course.level}</div>
          <h2>${course.title}</h2>
          <p>${course.description}</p>
        </div>
        <div class="card-icon"><i class="fas ${iconMap[course.image] || 'fa-book-open'}"></i></div>
      </div>
      ${modules}
    </div>
  `;

  openModal('courseModal');
}

async function markModuleComplete(courseId, moduleId, title) {
  if (!state.user) {
    openModal('authModal');
    showToast('Login required to save module progress.', 'error');
    return;
  }

  try {
    const data = await apiFetch(`/users/${encodeURIComponent(state.user.email)}/progress`, {
      method: 'PATCH',
      body: JSON.stringify({ courseId, moduleId, completed: true, title })
    });
    saveUserToStorage(data.user);
    state.dashboard = data.dashboard;
    renderDashboard(state.dashboard);
    showToast(`${title} marked complete.`);
    openCourse(courseId);
  } catch (error) {
    showToast(error.message, 'error');
  }
}

function openQuiz(quizId) {
  const quiz = state.quizzes.find((item) => item.id === quizId);
  if (!quiz) {
    return;
  }

  document.getElementById('quizDetail').innerHTML = `
    <div class="quiz-shell">
      <div class="card-top">
        <div>
          <div class="tag">${quiz.difficulty}</div>
          <h2>${quiz.title}</h2>
        </div>
        <div class="card-icon"><i class="fas fa-award"></i></div>
      </div>
      ${quiz.questions.map((question, index) => {
        if (question.type === 'mcq') {
          return `
            <div class="quiz-question">
              <strong>${index + 1}. ${question.prompt}</strong>
              <div class="stack-list" data-question-index="${index}">
                ${question.options.map((option, optionIndex) => `
                  <button class="quiz-option" onclick="selectQuizOption(${index}, ${optionIndex}, this)">${option}</button>
                `).join('')}
              </div>
            </div>
          `;
        }

        return `
          <div class="quiz-question">
            <strong>${index + 1}. ${question.prompt}</strong>
            <textarea rows="4" data-code-answer="${index}" placeholder="Type your short explanation or code-style answer here."></textarea>
          </div>
        `;
      }).join('')}
      <div class="card-actions">
        <button class="btn btn-primary" onclick="submitQuiz(${quiz.id})">Submit quiz</button>
      </div>
      <div id="quizFeedback"></div>
    </div>
  `;

  openModal('quizModal');
}

function selectQuizOption(questionIndex, optionIndex, button) {
  button.parentElement.querySelectorAll('.quiz-option').forEach((item) => item.classList.remove('selected'));
  button.classList.add('selected');
  button.parentElement.dataset.answer = optionIndex;
}

async function submitQuiz(quizId) {
  if (!state.user) {
    openModal('authModal');
    showToast('Login required to save quiz scores.', 'error');
    return;
  }

  const quiz = state.quizzes.find((item) => item.id === quizId);
  const answers = quiz.questions.map((question, index) => {
    if (question.type === 'mcq') {
      const wrap = document.querySelector(`[data-question-index="${index}"]`);
      return wrap?.dataset.answer ?? null;
    }
    return document.querySelector(`[data-code-answer="${index}"]`)?.value || '';
  });

  try {
    const result = await apiFetch(`/quizzes/${quizId}/submit`, {
      method: 'POST',
      body: JSON.stringify({ answers, userEmail: state.user.email })
    });
    if (result.dashboard) {
      state.dashboard = result.dashboard;
      saveUserToStorage(result.dashboard.user);
      renderDashboard(state.dashboard);
    }
    document.getElementById('quizFeedback').innerHTML = `
      <div class="module-grid">
        <h3>Score: ${result.score}%</h3>
        <p>${result.feedback}</p>
        <div class="tag-row">
          <span class="metric-chip">Correct: ${result.correct}/${result.total}</span>
        </div>
      </div>
    `;
    showToast(`Quiz submitted with ${result.score}% score.`);
  } catch (error) {
    showToast(error.message, 'error');
  }
}

function renderGuestDashboard() {
  document.getElementById('dashboardStatus').textContent = 'Sign in to see your personal progress, activity history, scores, and rewards.';
  document.getElementById('dashboardName').textContent = 'Guest learner';
  document.getElementById('dashboardLevel').textContent = 'Level 1 explorer';
  document.getElementById('dashboardPoints').textContent = '0';
  document.getElementById('dashboardModules').textContent = '0';
  document.getElementById('dashboardQuizzes').textContent = '0';
  document.getElementById('dashboardStreak').textContent = '0';
  document.getElementById('badgeContainer').innerHTML = '<span class="empty-text">No badges yet</span>';
  document.getElementById('progressContainer').innerHTML = '<div class="stack-item"><strong>No saved progress</strong><small>Complete modules after signing in.</small></div>';
  document.getElementById('quizPerformanceContainer').innerHTML = '<div class="stack-item"><strong>No quiz attempts</strong><small>Take a checkpoint to build your score history.</small></div>';
  document.getElementById('gamePerformanceContainer').innerHTML = '<div class="stack-item"><strong>No game attempts</strong><small>Play a mini-game to unlock entries here.</small></div>';
  document.getElementById('activityContainer').innerHTML = '<div class="stack-item"><strong>No recent activity</strong><small>Your learning timeline will appear here.</small></div>';
}

function renderDashboard(dashboard) {
  document.getElementById('dashboardStatus').textContent = `Tracking progress for ${dashboard.user.name}.`;
  document.getElementById('dashboardName').textContent = dashboard.user.name;
  document.getElementById('dashboardLevel').textContent = `Level ${dashboard.overview.level} explorer`;
  document.getElementById('dashboardPoints').textContent = dashboard.overview.points;
  document.getElementById('dashboardModules').textContent = dashboard.overview.completedModules;
  document.getElementById('dashboardQuizzes').textContent = dashboard.overview.quizzesTaken;
  document.getElementById('dashboardStreak').textContent = dashboard.overview.streak.current;

  document.getElementById('badgeContainer').innerHTML = dashboard.user.badges.length
    ? dashboard.user.badges.map((badge) => `<span class="badge-pill">${badge}</span>`).join('')
    : '<span class="empty-text">No badges yet</span>';

  document.getElementById('progressContainer').innerHTML = dashboard.courseProgress.map((item) => `
    <div class="stack-item">
      <strong>${item.title}</strong>
      <small>${item.completed}/${item.total} modules complete</small>
      <div class="progress-track"><span class="progress-fill" style="width:${item.percent}%"></span></div>
    </div>
  `).join('');

  document.getElementById('quizPerformanceContainer').innerHTML = dashboard.quizScores.map((item) => `
    <div class="stack-item">
      <strong>${item.title}</strong>
      <small>${item.difficulty} | Best score ${item.bestScore}% | Attempts ${item.attempts}</small>
    </div>
  `).join('');

  document.getElementById('gamePerformanceContainer').innerHTML = dashboard.gamePerformance.map((item) => `
    <div class="stack-item">
      <strong>${item.name}</strong>
      <small>${item.category} | Best score ${item.bestScore} | Attempts ${item.attempts}</small>
    </div>
  `).join('');

  document.getElementById('activityContainer').innerHTML = dashboard.recentActivity.length
    ? dashboard.recentActivity.map((item) => `
      <div class="stack-item">
        <strong>${item.title}</strong>
        <small>${item.details}</small>
      </div>
    `).join('')
    : '<div class="stack-item"><strong>No recent activity</strong><small>Start learning to populate this feed.</small></div>';

  renderLeaderboard(dashboard.leaderboard);
}

function renderLeaderboard(rows) {
  document.getElementById('leaderboardContainer').innerHTML = rows.map((row) => `
    <div class="leaderboard-row">
      <div class="rank-pill">${row.rank}</div>
      <div>
        <strong>${row.name}</strong>
        <span>Level ${row.level} | Streak ${row.streak} | ${row.badges} badges</span>
      </div>
      <strong>${row.points} pts</strong>
    </div>
  `).join('');
}

async function runCode() {
  const language = document.getElementById('languageSelect').value;
  const code = document.getElementById('codeEditor').value;
  try {
    const result = await apiFetch('/playground/run', {
      method: 'POST',
      body: JSON.stringify({ language, code, userEmail: state.user?.email || '' })
    });
    document.getElementById('codeOutput').textContent = `${result.output}\n\nHint: ${result.hint}`;
    if (result.dashboard) {
      state.dashboard = result.dashboard;
      saveUserToStorage(result.dashboard.user);
      renderDashboard(result.dashboard);
    }
    showToast('Playground code processed successfully.');
  } catch (error) {
    showToast(error.message, 'error');
  }
}

async function askQuestion() {
  const input = document.getElementById('tutorInput');
  const question = input.value.trim();
  if (!question) {
    showToast('Type a question first.', 'error');
    return;
  }

  try {
    const result = await apiFetch('/questions', {
      method: 'POST',
      body: JSON.stringify({
        question,
        userEmail: state.user?.email || '',
        authorName: state.user?.name || 'Guest learner'
      })
    });
    state.questions = result.questions;
    renderQuestions();
    input.value = '';
    if (state.user) {
      await refreshDashboard();
    }
    showToast('Question posted successfully.');
  } catch (error) {
    showToast(error.message, 'error');
  }
}

async function createClassroom() {
  const input = document.getElementById('classroomNameInput');
  const name = input.value.trim();
  if (!name) {
    showToast('Enter a classroom name.', 'error');
    return;
  }

  try {
    const result = await apiFetch('/classrooms', {
      method: 'POST',
      body: JSON.stringify({
        name,
        creatorEmail: state.user?.email || '',
        creatorName: state.user?.name || 'Host'
      })
    });
    state.classrooms = result.classrooms;
    state.currentClassroom = result.classroom;
    renderClassrooms();
    input.value = '';
    if (state.user) {
      await refreshDashboard();
    }
    showToast(`Classroom created. Share code ${result.classroom.code}.`);
  } catch (error) {
    showToast(error.message, 'error');
  }
}

async function joinClassroom() {
  const input = document.getElementById('joinClassroomCodeInput');
  const code = input.value.trim().toUpperCase();
  if (!code) {
    showToast('Enter a classroom code.', 'error');
    return;
  }

  try {
    const result = await apiFetch('/classrooms/join', {
      method: 'POST',
      body: JSON.stringify({
        code,
        userEmail: state.user?.email || '',
        name: state.user?.name || 'Guest learner'
      })
    });
    state.classrooms = result.classrooms;
    state.currentClassroom = result.classroom;
    renderClassrooms();
    input.value = '';
    if (state.user) {
      await refreshDashboard();
    }
    showToast(`Joined classroom ${result.classroom.name}.`);
  } catch (error) {
    showToast(error.message, 'error');
  }
}

function selectClassroom(code) {
  state.currentClassroom = state.classrooms.find((room) => room.code === code) || null;
  renderClassrooms();
}

function applyPreset(language) {
  document.getElementById('languageSelect').value = language;
  document.getElementById('codeEditor').value = codeSnippets[language];
}

function launchGame(gameId) {
  const game = state.games.find((item) => item.id === gameId);
  if (!game) {
    return;
  }
  openModal('gameModal');
  document.getElementById('gameDetail').innerHTML = '';
  window.GameHub.openGame(game, state.user, async (dashboard) => {
    if (dashboard) {
      state.dashboard = dashboard;
      saveUserToStorage(dashboard.user);
      renderDashboard(dashboard);
    } else {
      await refreshDashboard();
    }
  }, showToast);
}

function openModal(modalId) {
  document.getElementById(modalId).classList.remove('hidden');
  document.body.classList.add('modal-open');
}

function closeModal(modalId) {
  document.getElementById(modalId).classList.add('hidden');
  if ([...document.querySelectorAll('.modal')].every((modal) => modal.classList.contains('hidden'))) {
    document.body.classList.remove('modal-open');
  }
}

function showToast(message, type = '') {
  const toast = document.createElement('div');
  toast.className = `toast ${type}`.trim();
  toast.textContent = message;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 2600);
}

window.openCourse = openCourse;
window.markModuleComplete = markModuleComplete;
window.openQuiz = openQuiz;
window.selectQuizOption = selectQuizOption;
window.submitQuiz = submitQuiz;
window.applyPreset = applyPreset;
window.launchGame = launchGame;
window.selectClassroom = selectClassroom;
window.showToast = showToast;
window.apiFetch = apiFetch;
