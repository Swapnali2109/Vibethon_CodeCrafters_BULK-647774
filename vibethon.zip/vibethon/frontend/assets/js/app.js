const API_URL = 'http://localhost:5000/api';

const state = {
  user: null,
  courses: [],
  quizzes: [],
  games: [],
  simulations: [],
  dashboard: null
};

const iconMap = {
  brain: 'fa-brain',
  database: 'fa-database',
  sitemap: 'fa-sitemap',
  'project-diagram': 'fa-project-diagram',
  eye: 'fa-eye',
  rocket: 'fa-rocket',
  'code-branch': 'fa-code-branch',
  filter: 'fa-filter',
  'wave-square': 'fa-wave-square'
};

const presets = {
  python: `# Spam detection starter
messages = ["buy now", "meeting at 5", "free prize"]
spam_terms = {"buy", "free", "prize"}

def spam_score(text):
    return sum(1 for token in text.split() if token.lower() in spam_terms)

for item in messages:
    print(item, "->", spam_score(item))
`,
  javascript: `const samples = [0.2, 0.8, -0.3];
const relu = (x) => Math.max(0, x);
const weights = [0.4, 0.9, 0.2];
const score = samples.reduce((sum, value, idx) => sum + value * weights[idx], 0);
console.log({ score, activated: relu(score) });`
};

const classificationRound = {
  current: 0,
  total: 8,
  score: 0,
  items: []
};

document.addEventListener('DOMContentLoaded', async () => {
  bindEvents();
  hydrateUser();
  await Promise.all([loadCourses(), loadQuizzes(), loadGames(), loadSimulations()]);
  initPlayground();
  initBonusFeatures();
  await refreshDashboard();
});

function bindEvents() {
  document.getElementById('authButton').addEventListener('click', () => {
    if (state.user) {
      logout();
      return;
    }
    openModal('authModal');
  });
  document.getElementById('heroStartBtn').addEventListener('click', () => openModal('authModal'));
  document.getElementById('loginForm').addEventListener('submit', login);
  document.getElementById('signupForm').addEventListener('submit', signup);
  document.getElementById('runCodeBtn').addEventListener('click', runCode);
  document.getElementById('languageSelect').addEventListener('change', (e) => {
    document.getElementById('codeEditor').value = presets[e.target.value] || '';
  });

  document.querySelectorAll('.tab-btn').forEach((btn) => {
    btn.addEventListener('click', () => switchAuthTab(btn.dataset.tab));
  });
  document.querySelectorAll('[data-close]').forEach((btn) => {
    btn.addEventListener('click', () => closeModal(btn.dataset.close));
  });
  document.querySelectorAll('.modal').forEach((modal) => {
    modal.addEventListener('click', (event) => {
      if (event.target === modal) {
        closeModal(modal.id);
      }
    });
  });
  document.querySelectorAll('[data-provider]').forEach((btn) => {
    btn.addEventListener('click', () => oauth(btn.dataset.provider));
  });
}

function initBonusFeatures() {
  const sendTutorBtn = document.getElementById('tutorSendBtn');
  const tutorInput = document.getElementById('tutorInput');
  const speakTopicBtn = document.getElementById('speakTopicBtn');
  const joinRoomBtn = document.getElementById('joinRoomBtn');
  const startChallengeBtn = document.getElementById('startChallengeBtn');
  const submitChallengeBtn = document.getElementById('submitChallengeBtn');

  if (sendTutorBtn && tutorInput) {
    sendTutorBtn.addEventListener('click', askTutor);
    tutorInput.addEventListener('keydown', (event) => {
      if (event.key === 'Enter') {
        askTutor();
      }
    });
    appendTutorMessage('tutor', 'Hi! I am your AI tutor. Ask me about ML concepts, quizzes, or project ideas.');
  }

  if (speakTopicBtn) {
    speakTopicBtn.addEventListener('click', speakSelectedTopic);
  }

  if (joinRoomBtn) {
    joinRoomBtn.addEventListener('click', joinCollaborativeRoom);
  }
  if (startChallengeBtn) {
    startChallengeBtn.addEventListener('click', startCollaborativeChallenge);
  }
  if (submitChallengeBtn) {
    submitChallengeBtn.addEventListener('click', submitCollaborativeProgress);
  }
}

async function api(path, options = {}) {
  const response = await fetch(`${API_URL}${path}`, {
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || 'Request failed');
  return data;
}

function hydrateUser() {
  const stored = localStorage.getItem('aimlCurrentUser');
  if (!stored) return;
  state.user = JSON.parse(stored);
  window.currentUser = state.user;
  updateAuthButton();
}

function persistUser(user) {
  state.user = user;
  window.currentUser = user;
  localStorage.setItem('aimlCurrentUser', JSON.stringify(user));
  updateAuthButton();
}

function updateAuthButton() {
  const el = document.getElementById('authButton');
  el.textContent = state.user ? `Logout ${state.user.name.split(' ')[0]}` : 'Sign In';
}

async function loadCourses() {
  state.courses = await api('/courses');
  const container = document.getElementById('coursesContainer');
  container.innerHTML = state.courses.map((course) => `
    <article class="course-card">
      <div class="card-top">
        <div><div class="tag">${course.level}</div><h3>${course.title}</h3></div>
        <div class="card-icon"><i class="fas ${iconMap[course.image] || 'fa-book'}"></i></div>
      </div>
      <div class="card-body">
        <p>${course.description}</p>
        <div class="card-meta"><span class="metric-chip">${course.duration}</span><span class="metric-chip">${course.modules.length} modules</span></div>
      </div>
      <div class="card-actions"><button class="btn btn-primary" onclick="openCourse(${course.id})">Open path</button></div>
    </article>
  `).join('');
}

async function loadQuizzes() {
  state.quizzes = await api('/quizzes');
  document.getElementById('quizzesContainer').innerHTML = state.quizzes.map((quiz) => `
    <article class="quiz-card">
      <div class="card-top"><div><div class="tag">${quiz.difficulty}</div><h3>${quiz.title}</h3></div><div class="card-icon"><i class="fas fa-clipboard-check"></i></div></div>
      <div class="card-body"><p>${quiz.questions.length} questions with instant feedback.</p></div>
      <div class="card-actions"><button class="btn btn-primary" onclick="openQuiz(${quiz.id})">Take quiz</button></div>
    </article>
  `).join('');
}

async function loadGames() {
  state.games = await api('/games');
  document.getElementById('gamesContainer').innerHTML = state.games.map((game) => `
    <article class="game-card">
      <div class="card-top">
        <div><div class="tag">${game.category}</div><h3>${game.name}</h3></div>
        <div class="card-icon"><i class="fas ${iconMap[game.image] || 'fa-gamepad'}"></i></div>
      </div>
      <div class="card-body"><p>${game.description}</p></div>
      <div class="card-actions"><button class="btn btn-primary" onclick="launchGame(${game.id})">Play now</button></div>
    </article>
  `).join('');
}

async function loadSimulations() {
  state.simulations = await api('/simulations');
  document.getElementById('simulationsContainer').innerHTML = state.simulations.map((item) => `
    <article class="simulation-card">
      <div class="tag">${item.category}</div>
      <h3>${item.title}</h3>
      <p>${item.description}</p>
      <div class="metric-chip">Dataset: ${item.dataset}</div>
      <ol class="simulation-steps">${item.steps.map((step) => `<li>${step}</li>`).join('')}</ol>
      <div class="simulation-metrics">${item.sampleMetrics.map((m) => `<span class="metric-chip">${m.label}: ${m.value}</span>`).join('')}</div>
    </article>
  `).join('');
}

function initPlayground() {
  document.getElementById('codeEditor').value = presets.python;
  document.getElementById('playgroundPresets').innerHTML = `
    <button class="preset-chip" onclick="applyPreset('python')">Python ML starter</button>
    <button class="preset-chip" onclick="applyPreset('javascript')">JS model math starter</button>
  `;
}

async function refreshDashboard() {
  if (!state.user) {
    renderGuestDashboard();
    return;
  }
  const dashboard = await api(`/users/${encodeURIComponent(state.user.email)}/dashboard`);
  state.dashboard = dashboard;
  persistUser(dashboard.user);
  renderDashboard(dashboard);
}

function renderGuestDashboard() {
  document.getElementById('dashboardStatus').textContent = 'Sign in to see your personal progress, activity history, scores, and rewards.';
  document.getElementById('dashboardName').textContent = 'Guest learner';
  document.getElementById('dashboardLevel').textContent = 'Level 1 explorer';
  ['dashboardPoints', 'dashboardModules', 'dashboardQuizzes', 'dashboardStreak'].forEach((id) => { document.getElementById(id).textContent = '0'; });
  document.getElementById('badgeContainer').innerHTML = '<span class="empty-text">No badges yet</span>';
  document.getElementById('progressContainer').innerHTML = '<div class="stack-item"><small>Login to track module completion.</small></div>';
  document.getElementById('quizPerformanceContainer').innerHTML = '<div class="stack-item"><small>Login to track quiz scores.</small></div>';
  document.getElementById('gamePerformanceContainer').innerHTML = '<div class="stack-item"><small>Login to track game performance.</small></div>';
  document.getElementById('activityContainer').innerHTML = '<div class="stack-item"><small>Recent activity appears here.</small></div>';
  renderLeaderboard([]);
}

function renderDashboard(data) {
  document.getElementById('dashboardStatus').textContent = `Welcome back ${data.user.name}. Keep your streak alive.`;
  document.getElementById('dashboardName').textContent = data.user.name;
  document.getElementById('dashboardLevel').textContent = `Level ${data.user.level} learner`;
  document.getElementById('dashboardPoints').textContent = data.overview.points;
  document.getElementById('dashboardModules').textContent = data.overview.completedModules;
  document.getElementById('dashboardQuizzes').textContent = data.overview.quizzesTaken;
  document.getElementById('dashboardStreak').textContent = data.overview.streak?.current || 0;

  document.getElementById('badgeContainer').innerHTML = data.user.badges.length
    ? data.user.badges.map((badge) => `<span class="badge-pill">${badge}</span>`).join('')
    : '<span class="empty-text">No badges yet</span>';

  document.getElementById('progressContainer').innerHTML = data.courseProgress.map((item) => `
    <div class="stack-item"><strong>${item.title}</strong><small>${item.completed}/${item.total} modules</small><div class="progress-track"><span class="progress-fill" style="width:${item.percent}%"></span></div></div>
  `).join('');
  document.getElementById('quizPerformanceContainer').innerHTML = data.quizScores.map((item) => `
    <div class="stack-item"><strong>${item.title}</strong><small>${item.attempts} attempts | Best ${item.bestScore}%</small></div>
  `).join('');
  document.getElementById('gamePerformanceContainer').innerHTML = data.gamePerformance.map((item) => `
    <div class="stack-item"><strong>${item.name}</strong><small>${item.attempts} attempts | Best ${item.bestScore}</small></div>
  `).join('');
  document.getElementById('activityContainer').innerHTML = data.recentActivity.map((item) => `
    <div class="stack-item"><strong>${item.title}</strong><small>${item.details}</small></div>
  `).join('') || '<div class="stack-item"><small>No activity yet.</small></div>';
  renderLeaderboard(data.leaderboard || []);
}

function renderLeaderboard(rows) {
  const fallback = [{ rank: 1, name: 'No scores yet', points: 0, level: 1 }];
  const data = rows.length ? rows : fallback;
  document.getElementById('leaderboardContainer').innerHTML = data.map((row) => `
    <div class="leaderboard-row">
      <span class="rank-pill">${row.rank}</span>
      <div><strong>${row.name}</strong><span>Level ${row.level}</span></div>
      <strong>${row.points} pts</strong>
    </div>
  `).join('');
}

function openCourse(courseId) {
  const course = state.courses.find((entry) => entry.id === courseId);
  if (!course) return;
  document.getElementById('courseDetail').innerHTML = `
    <div class="course-detail-shell">
      <h2>${course.title}</h2>
      <p>${course.description}</p>
      ${course.modules.map((module, idx) => `
        <div class="module-grid">
          <h3>Module ${idx + 1}: ${module.name}</h3>
          <p>${module.summary || ''}</p>
          <p>${module.content}</p>
          <div class="tag-row">${(module.examples || []).map((ex) => `<span class="tag">${ex}</span>`).join('')}</div>
          ${module.visualAid ? `<div class="small-visual">${renderVisual(module.visualAid)}</div>` : ''}
          <button class="btn btn-secondary" onclick="completeModule(${course.id}, ${module.id}, '${escapeText(module.name)}')">Mark complete</button>
        </div>
      `).join('')}
    </div>
  `;
  openModal('courseModal');
}

function renderVisual(visualAid) {
  return `<strong>${visualAid.title}</strong><div class="visual-chart">${visualAid.labels.map((label, idx) => `<div class="visual-bar"><span>${label}</span><i style="width:${Math.min(100, visualAid.values[idx])}%"></i></div>`).join('')}</div>`;
}

async function completeModule(courseId, moduleId, title) {
  if (!state.user) return showToast('Login required to save progress.', 'error');
  await api(`/users/${encodeURIComponent(state.user.email)}/progress`, {
    method: 'PATCH',
    body: JSON.stringify({ courseId, moduleId, completed: true, title })
  });
  await refreshDashboard();
  showToast('Module completed and progress saved.');
}

function openQuiz(quizId) {
  const quiz = state.quizzes.find((entry) => entry.id === quizId);
  if (!quiz) return;
  document.getElementById('quizDetail').innerHTML = `
    <div class="quiz-shell">
      <h2>${quiz.title}</h2>
      ${quiz.questions.map((q, idx) => `
        <div class="quiz-question">
          <strong>${idx + 1}. ${q.prompt}</strong>
          ${q.type === 'mcq'
            ? q.options.map((opt, optionIdx) => `<label class="quiz-option"><input type="radio" name="quiz-${q.id}" value="${optionIdx}"> ${opt}</label>`).join('')
            : `<textarea id="code-answer-${q.id}" rows="4" placeholder="Type your reasoning or code response"></textarea>`}
        </div>
      `).join('')}
      <button class="btn btn-primary" onclick="submitQuiz(${quiz.id})">Submit quiz</button>
      <div id="quizResult"></div>
    </div>
  `;
  openModal('quizModal');
}

async function submitQuiz(quizId) {
  const quiz = state.quizzes.find((entry) => entry.id === quizId);
  if (!quiz) return;
  const answers = quiz.questions.map((q) => {
    if (q.type === 'mcq') {
      const checked = document.querySelector(`input[name="quiz-${q.id}"]:checked`);
      return checked ? Number(checked.value) : null;
    }
    return document.getElementById(`code-answer-${q.id}`)?.value || '';
  });
  const result = await api(`/quizzes/${quizId}/submit`, {
    method: 'POST',
    body: JSON.stringify({ answers, userEmail: state.user?.email || '' })
  });
  document.getElementById('quizResult').innerHTML = `<div class="stack-item"><strong>Score: ${result.score}%</strong><small>${result.feedback}</small></div>`;
  if (state.user) await refreshDashboard();
}

function launchGame(gameId) {
  if (!state.user) return showToast('Login required to save game scores.', 'error');
  const game = state.games.find((entry) => entry.id === gameId);
  if (!game) return;
  let gameMarkup = `<div class="game-shell"><h2>${game.name}</h2><p>${game.description}</p>`;
  if (gameId === 1) {
    gameMarkup += `<div id="dtCanvas" class="small-visual"></div><div class="game-stage"><div id="dtScore">Score: 0</div><button class="btn btn-secondary" onclick="resetDecisionTree()">Reset</button></div>`;
  } else if (gameId === 2) {
    gameMarkup += `
      <div class="small-visual" id="classificationBoard"></div>
      <div class="game-stage" style="text-align:center;">
        <button class="btn btn-primary" onclick="classifyItem('spam')">Spam</button>
        <button class="btn btn-secondary" onclick="classifyItem('ham')">Not spam</button>
        <div id="clsScore">Score: 0/8</div>
      </div>`;
  } else {
    gameMarkup += `<canvas id="nnCanvas" width="460" height="280" class="game-stage"></canvas><div class="game-stage"><button class="btn btn-primary" onclick="trainNeuralNet()">Train step</button> <button class="btn btn-secondary" onclick="resetNeuralNet()">Reset</button> <span id="nnScore">Accuracy: 0%</span></div>`;
  }
  gameMarkup += `<button class="btn btn-primary" onclick="saveGameScore(${gameId})">Save score</button></div>`;
  document.getElementById('gameDetail').innerHTML = gameMarkup;
  openModal('gameModal');
  setTimeout(() => {
    if (gameId === 1) initDecisionTree();
    if (gameId === 2) initClassificationSorter();
    if (gameId === 3) initNeuralNetwork();
  }, 60);
}

async function saveGameScore(gameId) {
  const scoreText = document.getElementById(gameId === 2 ? 'clsScore' : gameId === 3 ? 'nnScore' : 'dtScore')?.textContent || '0';
  const score = Number(scoreText.replace(/[^\d]/g, '')) || 0;
  await api(`/games/${gameId}/score`, {
    method: 'POST',
    body: JSON.stringify({ userEmail: state.user.email, score, title: 'Mini game session' })
  });
  await refreshDashboard();
  showToast('Game score saved.');
}

async function runCode() {
  const code = document.getElementById('codeEditor').value;
  const language = document.getElementById('languageSelect').value;
  const result = await api('/playground/run', {
    method: 'POST',
    body: JSON.stringify({ language, code, userEmail: state.user?.email || '' })
  });
  document.getElementById('codeOutput').textContent = result.output;
  if (state.user) await refreshDashboard();
}

async function login(event) {
  event.preventDefault();
  const form = new FormData(event.target);
  const data = await api('/users/login', {
    method: 'POST',
    body: JSON.stringify({ email: form.get('email'), password: form.get('password') })
  });
  persistUser(data.user);
  closeModal('authModal');
  await refreshDashboard();
  showToast('Logged in successfully.');
}

async function signup(event) {
  event.preventDefault();
  const form = new FormData(event.target);
  const data = await api('/users/register', {
    method: 'POST',
    body: JSON.stringify({ name: form.get('name'), email: form.get('email'), password: form.get('password') })
  });
  persistUser(data.user);
  closeModal('authModal');
  await refreshDashboard();
  showToast('Account created.');
}

async function oauth(provider) {
  const suffix = Date.now().toString().slice(-5);
  const data = await api('/users/oauth', {
    method: 'POST',
    body: JSON.stringify({
      provider,
      email: `${provider}.${suffix}@example.com`,
      name: `${provider.toUpperCase()} Learner`
    })
  });
  persistUser(data.user);
  closeModal('authModal');
  await refreshDashboard();
  showToast(`Signed in with ${provider}.`);
}

async function logout() {
  await api('/users/logout', { method: 'POST', body: JSON.stringify({}) }).catch(() => {});
  state.user = null;
  window.currentUser = null;
  localStorage.removeItem('aimlCurrentUser');
  updateAuthButton();
  renderGuestDashboard();
  showToast('Logged out.');
}

function applyPreset(language) {
  document.getElementById('languageSelect').value = language;
  document.getElementById('codeEditor').value = presets[language];
}

function switchAuthTab(tab) {
  document.querySelectorAll('.tab-btn').forEach((el) => el.classList.toggle('active', el.dataset.tab === tab));
  document.querySelectorAll('.auth-form').forEach((el) => el.classList.toggle('active', el.id === `${tab}Form`));
}

function openModal(id) {
  document.getElementById(id).classList.remove('hidden');
  document.body.classList.add('modal-open');
}

function closeModal(id) {
  document.getElementById(id).classList.add('hidden');
  if (![...document.querySelectorAll('.modal')].some((modal) => !modal.classList.contains('hidden'))) {
    document.body.classList.remove('modal-open');
  }
}

function showToast(message, type = '') {
  const node = document.createElement('div');
  node.className = `toast ${type}`.trim();
  node.textContent = message;
  document.body.appendChild(node);
  setTimeout(() => node.remove(), 2400);
}

function escapeText(value = '') {
  return String(value).replace(/'/g, "\\'");
}

function appendTutorMessage(role, text) {
  const box = document.getElementById('tutorMessages');
  if (!box) return;
  const item = document.createElement('div');
  item.className = `tutor-msg ${role}`;
  item.textContent = text;
  box.appendChild(item);
  box.scrollTop = box.scrollHeight;
}

function generateTutorReply(prompt) {
  const text = prompt.toLowerCase();
  if (text.includes('decision tree')) {
    return 'Decision trees split data into branches using features that maximize information gain. Start with the cleanest split first.';
  }
  if (text.includes('neural') || text.includes('backprop')) {
    return 'Neural networks learn by forward pass + loss + backpropagation. Tune learning rate and regularization to avoid overfitting.';
  }
  if (text.includes('quiz') || text.includes('score')) {
    return 'For better quiz scores: review module examples, then solve one code-based question in your own words.';
  }
  if (text.includes('project') || text.includes('simulation')) {
    return 'Start from problem framing: objective, dataset quality, baseline model, and one measurable metric.';
  }
  return 'Good question. Break it into: data, model, metric, and improvement loop. I can explain any one in detail.';
}

function askTutor() {
  const input = document.getElementById('tutorInput');
  if (!input) return;
  const prompt = input.value.trim();
  if (!prompt) return;
  appendTutorMessage('user', prompt);
  const reply = generateTutorReply(prompt);
  setTimeout(() => appendTutorMessage('tutor', reply), 240);
  input.value = '';
}

function speakSelectedTopic() {
  const select = document.getElementById('voiceTopicSelect');
  if (!select) return;
  const scripts = {
    'supervised-learning': 'Supervised learning uses labeled data to learn input-to-output mappings and make predictions on unseen samples.',
    'decision-trees': 'Decision trees recursively split datasets using high-information features, creating interpretable model rules.',
    'neural-networks': 'Neural networks stack layers of weighted transformations. Backpropagation updates weights to reduce prediction loss.',
    'model-evaluation': 'Model evaluation compares predictions against truth using metrics like accuracy, precision, recall, and F1 score.'
  };
  const text = scripts[select.value] || scripts['supervised-learning'];
  if (!window.speechSynthesis) {
    showToast('Speech is not supported in this browser.', 'error');
    return;
  }
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.rate = 1;
  utterance.pitch = 1;
  window.speechSynthesis.speak(utterance);
  showToast('Playing voice explanation.');
}

function roomKey(name) {
  return `aiml-collab-room-${name}`;
}

function joinCollaborativeRoom() {
  const input = document.getElementById('collabRoomInput');
  const status = document.getElementById('collabRoomStatus');
  if (!input || !status) return;
  const room = input.value.trim();
  if (!room) {
    showToast('Enter a room name first.', 'error');
    return;
  }
  localStorage.setItem('aiml-collab-active-room', room);
  const userName = state.user?.name || 'Guest Learner';
  const initial = {
    challenge: null,
    leaderboard: [
      { name: userName, points: 0 },
      { name: 'TeamBot Alpha', points: 6 },
      { name: 'TeamBot Beta', points: 4 }
    ]
  };
  const existing = localStorage.getItem(roomKey(room));
  if (!existing) {
    localStorage.setItem(roomKey(room), JSON.stringify(initial));
  }
  status.textContent = `Connected to room: ${room}`;
  renderCollaborativeBoard();
}

function startCollaborativeChallenge() {
  const room = localStorage.getItem('aiml-collab-active-room');
  if (!room) {
    showToast('Join a room first.', 'error');
    return;
  }
  const raw = localStorage.getItem(roomKey(room));
  const data = raw ? JSON.parse(raw) : { leaderboard: [] };
  data.challenge = {
    title: 'Classify 10 samples under 90 seconds',
    startedAt: Date.now(),
    endsAt: Date.now() + 90000
  };
  localStorage.setItem(roomKey(room), JSON.stringify(data));
  showToast('Challenge started. Submit progress to earn points.');
  renderCollaborativeBoard();
}

function submitCollaborativeProgress() {
  const room = localStorage.getItem('aiml-collab-active-room');
  if (!room) {
    showToast('Join a room first.', 'error');
    return;
  }
  const raw = localStorage.getItem(roomKey(room));
  const data = raw ? JSON.parse(raw) : { leaderboard: [] };
  const userName = state.user?.name || 'Guest Learner';
  const row = data.leaderboard.find((entry) => entry.name === userName);
  if (row) {
    row.points += 10;
  } else {
    data.leaderboard.push({ name: userName, points: 10 });
  }
  data.leaderboard = data.leaderboard.sort((a, b) => b.points - a.points);
  localStorage.setItem(roomKey(room), JSON.stringify(data));
  showToast('Progress submitted: +10 points.');
  renderCollaborativeBoard();
}

function renderCollaborativeBoard() {
  const room = localStorage.getItem('aiml-collab-active-room');
  const board = document.getElementById('collabLeaderboard');
  const status = document.getElementById('collabRoomStatus');
  if (!board || !status) return;
  if (!room) {
    board.innerHTML = '';
    return;
  }
  const raw = localStorage.getItem(roomKey(room));
  const data = raw ? JSON.parse(raw) : { leaderboard: [] };
  const challengeText = data.challenge
    ? `Live: ${data.challenge.title}`
    : 'No live challenge yet.';
  status.textContent = `Connected to room: ${room} | ${challengeText}`;
  board.innerHTML = data.leaderboard.slice(0, 5).map((entry, idx) => (
    `<div class="collab-item"><strong>#${idx + 1} ${entry.name}</strong><span>${entry.points} pts</span></div>`
  )).join('');
}

function initClassificationSorter() {
  const items = [
    { text: 'Limited offer free prize now', label: 'spam' },
    { text: 'Team standup at 10am', label: 'ham' },
    { text: 'URGENT: claim your bonus', label: 'spam' },
    { text: 'Please review the dataset report', label: 'ham' },
    { text: 'Win cash instantly, click here', label: 'spam' },
    { text: 'Can we sync on model metrics?', label: 'ham' },
    { text: 'Lowest rate buy now', label: 'spam' },
    { text: 'Lunch after sprint review?', label: 'ham' }
  ];
  classificationRound.items = items.sort(() => Math.random() - 0.5);
  classificationRound.current = 0;
  classificationRound.score = 0;
  classificationRound.total = classificationRound.items.length;
  renderClassificationItem();
}

function renderClassificationItem() {
  const board = document.getElementById('classificationBoard');
  const scoreEl = document.getElementById('clsScore');
  if (!board || !scoreEl) return;
  if (classificationRound.current >= classificationRound.total) {
    board.innerHTML = `<strong>Round complete!</strong><p>Great job sorting messages.</p>`;
    scoreEl.textContent = `Final: ${classificationRound.score}/${classificationRound.total}`;
    return;
  }
  const item = classificationRound.items[classificationRound.current];
  board.innerHTML = `
    <strong>Message ${classificationRound.current + 1}/${classificationRound.total}</strong>
    <p style="margin:10px 0 0;">"${item.text}"</p>
    <div class="game-meter" style="margin-top:12px;"><span style="width:${Math.round((classificationRound.current / classificationRound.total) * 100)}%"></span></div>`;
  scoreEl.textContent = `Score: ${classificationRound.score}/${classificationRound.total}`;
}

function classifyItem(choice) {
  const current = classificationRound.items[classificationRound.current];
  if (!current) return;
  if (choice === current.label) {
    classificationRound.score += 1;
    showToast('Correct classification.');
  } else {
    showToast(`Not quite. Correct: ${current.label === 'spam' ? 'Spam' : 'Not spam'}`, 'error');
  }
  classificationRound.current += 1;
  renderClassificationItem();
}

window.openCourse = openCourse;
window.completeModule = completeModule;
window.openQuiz = openQuiz;
window.submitQuiz = submitQuiz;
window.launchGame = launchGame;
window.saveGameScore = saveGameScore;
window.applyPreset = applyPreset;
window.showNotification = showToast;
window.classifyItem = classifyItem;
