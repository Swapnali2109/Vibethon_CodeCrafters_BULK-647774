// ========================
// Fun Learning Features
// ========================

// Daily Challenge System
class DailyChallengeSystem {
    constructor() {
        this.challenges = this.generateDailyChallenges();
        this.today = new Date().toDateString();
    }

    generateDailyChallenges() {
        return [
            {
                id: 1,
                title: "Quick Quiz Champion",
                description: "Answer 3 ML questions correctly",
                reward: 100,
                icon: "🧠",
                type: "quiz"
            },
            {
                id: 2,
                title: "Game Master",
                description: "Reach 500 score in any game",
                reward: 150,
                icon: "🎮",
                type: "game"
            },
            {
                id: 3,
                title: "Streak Keeper",
                description: "Complete a course module",
                reward: 50,
                icon: "🔥",
                type: "module"
            },
            {
                id: 4,
                title: "Code Wizard",
                description: "Successfully execute code",
                reward: 75,
                icon: "💻",
                type: "code"
            },
            {
                id: 5,
                title: "Learning Legend",
                description: "Spend 30 minutes learning",
                reward: 80,
                icon: "⭐",
                type: "time"
            }
        ];
    }

    getTodaysChallenges() {
        return this.challenges.slice(0, 3);
    }

    getChallengeProgress(userEmail) {
        const stored = localStorage.getItem(`challenges_${userEmail}_${this.today}`);
        return stored ? JSON.parse(stored) : {};
    }

    updateChallengeProgress(userEmail, challengeId) {
        const key = `challenges_${userEmail}_${this.today}`;
        const progress = this.getChallengeProgress(userEmail);
        progress[challengeId] = true;
        localStorage.setItem(key, JSON.stringify(progress));
    }
}

// Streak System
class StreakSystem {
    constructor(userEmail) {
        this.userEmail = userEmail;
        this.key = `streak_${userEmail}`;
        this.loadStreak();
    }

    loadStreak() {
        const stored = localStorage.getItem(this.key);
        if (stored) {
            this.streak = JSON.parse(stored);
        } else {
            this.streak = { count: 0, lastDate: null, bestCount: 0 };
        }
    }

    updateStreak() {
        const today = new Date().toDateString();
        
        if (this.streak.lastDate === today) {
            return this.streak.count; // Already updated today
        }

        const lastDate = this.streak.lastDate ? new Date(this.streak.lastDate) : null;
        const todayDate = new Date();

        if (lastDate) {
            const dayDiff = Math.floor((todayDate - lastDate) / (1000 * 60 * 60 * 24));
            
            if (dayDiff === 1) {
                this.streak.count++;
            } else if (dayDiff > 1) {
                this.streak.count = 1;
            }
        } else {
            this.streak.count = 1;
        }

        this.streak.lastDate = today;
        this.streak.bestCount = Math.max(this.streak.bestCount, this.streak.count);
        this.saveStreak();

        return this.streak.count;
    }

    saveStreak() {
        localStorage.setItem(this.key, JSON.stringify(this.streak));
    }

    getStreak() {
        return this.streak;
    }
}

// Module Challenges (Interactive activities within modules)
const moduleChallenges = {
    1: [ // Introduction to ML courses
        {
            id: 'ml_1_1',
            type: 'interactive',
            title: 'Supervised vs Unsupervised',
            description: 'Drag the examples to the correct learning type',
            reward: 75,
            icon: '🎯',
            examples: [
                { text: 'Email spam detection', type: 'supervised' },
                { text: 'Customer segmentation', type: 'unsupervised' },
                { text: 'House price prediction', type: 'supervised' },
                { text: 'Finding document clusters', type: 'unsupervised' }
            ]
        },
        {
            id: 'ml_1_2',
            type: 'quiz',
            title: 'Quick Quiz',
            description: 'Answer 2 questions about ML fundamentals',
            reward: 50,
            icon: '❓',
            questions: [
                { q: 'What is overfitting?', a: 'Model learns training data too well' },
                { q: 'Why split data?', a: 'To evaluate on unseen data' }
            ]
        }
    ],
    2: [ // Deep Learning
        {
            id: 'dl_1_1',
            type: 'interactive',
            title: 'Network Architecture Builder',
            description: 'Build a neural network layer by layer',
            reward: 100,
            icon: '🧠',
            layers: ['Input', 'Hidden 1', 'Hidden 2', 'Output']
        }
    ],
    3: [ // NLP
        {
            id: 'nlp_1_1',
            type: 'interactive',
            title: 'Text Tokenizer',
            description: 'Split sentences into tokens',
            reward: 75,
            icon: '📝',
            examples: ['The quick brown fox', 'Natural language processing is fun']
        }
    ]
};

// Fun Learning Animations
function celebrateAchievement(title, icon, points) {
    // Save achievement to localStorage
    if (currentUser) {
        const achievements = JSON.parse(localStorage.getItem(`achievements_${currentUser.email}`) || '[]');
        achievements.unshift({
            name: title,
            icon: icon,
            points: points,
            timestamp: new Date().toLocaleString()
        });
        // Keep only last 10 achievements
        if (achievements.length > 10) achievements.pop();
        localStorage.setItem(`achievements_${currentUser.email}`, JSON.stringify(achievements));
    }
    
    const celebration = document.createElement('div');
    celebration.style.cssText = `
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: linear-gradient(135deg, #6C5CE7, #A29BFE);
        color: white;
        padding: 3rem 4rem;
        border-radius: 20px;
        box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        z-index: 5000;
        text-align: center;
        animation: celebrateIn 0.5s ease-out;
        font-size: 2rem;
    `;
    celebration.innerHTML = `
        <div style="font-size: 4rem; margin-bottom: 1rem; animation: bounce 0.6s ease-out;">
            ${icon}
        </div>
        <h2 style="font-size: 2rem; margin-bottom: 0.5rem;">${title}</h2>
        <p style="font-size: 1.5rem; margin-bottom: 0.5rem;">+${points} Points!</p>
    `;

    document.body.appendChild(celebration);

    // Confetti effect
    createConfetti();

    setTimeout(() => {
        celebration.style.animation = 'celebrateOut 0.5s ease-in';
        setTimeout(() => celebration.remove(), 500);
    }, 2000);
}

function createConfetti() {
    const confettiPieces = 50;
    const colors = ['#6C5CE7', '#A29BFE', '#00B894', '#FDCB6E', '#FF7675'];

    for (let i = 0; i < confettiPieces; i++) {
        const confetti = document.createElement('div');
        const size = Math.random() * 10 + 5;
        const duration = Math.random() * 3 + 2;
        const delay = Math.random() * 0.2;
        const angle = (Math.random() * 360) + 'deg';
        const distance = Math.random() * 300 + 200;

        confetti.style.cssText = `
            position: fixed;
            width: ${size}px;
            height: ${size}px;
            background: ${colors[Math.floor(Math.random() * colors.length)]};
            border-radius: 50%;
            left: 50%;
            top: 50%;
            pointer-events: none;
            z-index: 5001;
            animation: confettiFall ${duration}s ease-in forwards ${delay}s;
            transform: rotate(${angle}) translateY(0);
        `;
        document.body.appendChild(confetti);
        setTimeout(() => confetti.remove(), (duration + delay) * 1000);
    }
}

// Milestone System
const milestones = [
    { points: 250, icon: '🥉', name: 'Bronze Learner', reward: 'Unlocked Bronze Badge' },
    { points: 500, icon: '🥈', name: 'Silver Scholar', reward: 'Unlocked Silver Badge' },
    { points: 1000, icon: '🥇', name: 'Gold Expert', reward: 'Unlocked Gold Badge' },
    { points: 2000, icon: '💎', name: 'Platinum Master', reward: 'Unlocked Platinum Badge' },
    { points: 5000, icon: '👑', name: 'AI Legend', reward: 'Unlocked Legend Status' }
];

function checkMilestones(points, userEmail) {
    const milestonesList = [
        { points: 250, name: 'Bronze Master', icon: '🥉', label: 'Bronze' },
        { points: 500, name: 'Silver Expert', icon: '🥈', label: 'Silver' },
        { points: 1000, name: 'Gold Champion', icon: '🥇', label: 'Gold' },
        { points: 2000, name: 'Diamond Legend', icon: '💎', label: 'Diamond' },
        { points: 5000, name: 'Platinum King', icon: '👑', label: 'Platinum' }
    ];
    
    const completedMilestones = localStorage.getItem(`milestones_${userEmail}`) 
        ? JSON.parse(localStorage.getItem(`milestones_${userEmail}`)) 
        : {};
    
    // Store user points as well
    localStorage.setItem(`userPoints_${userEmail}`, points);

    milestonesList.forEach(milestone => {
        if (points >= milestone.points && !completedMilestones[milestone.label]) {
            celebrateAchievement(milestone.name, milestone.icon, 500);
            completedMilestones[milestone.label] = true;
            localStorage.setItem(`milestones_${userEmail}`, JSON.stringify(completedMilestones));
        }
    });
}

// Fun Learning Tips & Facts
const funFacts = [
    "💡 Did you know? Neural networks were inspired by how brains work!",
    "🧠 Fun fact: AI can now generate images from descriptions!",
    "🎯 Tip: Focus on understanding concepts, not memorizing them.",
    "⚡ Speed tip: Spaced repetition helps you learn faster!",
    "🎮 Pro tip: Playing games actually strengthens learning!",
    "📚 Fun fact: The first neural network was created in 1951!",
    "🚀 Did you know? GPT-3 has 175 billion parameters!",
    "🔥 Motivation: Every expert was once a beginner!",
    "💻 Tip: Practice coding to master ML concepts!",
    "🌟 Fact: Machine Learning powers Netflix recommendations!"
];

function getRandomFunFact() {
    return funFacts[Math.floor(Math.random() * funFacts.length)];
}

// Interactive Learning Activities
function createModuleChallenge(challenge) {
    if (challenge.type === 'interactive') {
        return createInteractiveChallenge(challenge);
    } else if (challenge.type === 'quiz') {
        return createQuizChallenge(challenge);
    }
}

function createInteractiveChallenge(challenge) {
    let html = `
        <div class="module-challenge" style="
            background: linear-gradient(135deg, #f5f7fa, #e8eaed);
            padding: 1.5rem;
            border-radius: 12px;
            margin: 1.5rem 0;
            border: 2px solid #6C5CE7;
        ">
            <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1rem;">
                <span style="font-size: 2rem;">${challenge.icon}</span>
                <div>
                    <h4 style="margin: 0; color: #2D3436;">${challenge.title}</h4>
                    <p style="margin: 0; color: #636E72; font-size: 0.9rem;">${challenge.description}</p>
                </div>
                <span style="mleft: auto; background: #00B894; color: white; padding: 0.5rem 1rem; border-radius: 20px; font-weight: 600;">+${challenge.reward} pts</span>
            </div>
            
            <div id="challenge_${challenge.id}" class="challenge-content" style="
                background: white;
                padding: 1rem;
                border-radius: 8px;
            "></div>
        </div>
    `;
    return html;
}

function createQuizChallenge(challenge) {
    let html = `
        <div class="module-challenge" style="
            background: linear-gradient(135deg, #fffacd, #ffe4b5);
            padding: 1.5rem;
            border-radius: 12px;
            margin: 1.5rem 0;
            border: 2px solid #FDCB6E;
        ">
            <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1rem;">
                <span style="font-size: 2rem;">${challenge.icon}</span>
                <div>
                    <h4 style="margin: 0; color: #2D3436;">${challenge.title}</h4>
                    <p style="margin: 0; color: #636E72; font-size: 0.9rem;">${challenge.description}</p>
                </div>
                <span style="margin-left: auto; background: #FDCB6E; color: white; padding: 0.5rem 1rem; border-radius: 20px; font-weight: 600;">+${challenge.reward} pts</span>
            </div>
            
            <div style="background: white; padding: 1rem; border-radius: 8px;">
                ${challenge.questions.map((q, i) => `
                    <div style="margin-bottom: 0.75rem;">
                        <label style="display: flex; align-items: center; gap: 0.5rem; cursor: pointer;">
                            <input type="checkbox" class="quiz-check">
                            <strong>${q.q}</strong>
                        </label>
                    </div>
                `).join('')}
                <button onclick="completeChallenge(this, '${challenge.id}', ${challenge.reward})" class="btn btn-primary" style="margin-top: 1rem; width: 100%;">
                    Complete Challenge
                </button>
            </div>
        </div>
    `;
    return html;
}

function completeChallenge(button, challengeId, reward) {
    if (!currentUser) {
        showNotification('Please login to complete challenges', 'error');
        openAuthModal();
        return;
    }

    const completed = localStorage.getItem(`challenge_${currentUser.email}_${challengeId}`);
    if (completed) {
        showNotification('Already completed this challenge today!', 'warning');
        return;
    }

    currentUser.points += reward;
    localStorage.setItem('currentUser', JSON.stringify(currentUser));
    localStorage.setItem(`challenge_${currentUser.email}_${challengeId}`, 'true');
    
    celebrateAchievement('Challenge Completed!', '⭐', reward);
    checkMilestones(currentUser.points, currentUser.email);
    updateDashboard();
    
    button.disabled = true;
    button.textContent = '✓ Completed';
    button.style.background = '#00B894';
}

// Gamified Progress
function createProgressRing(percentage) {
    const radius = 45;
    const circumference = 2 * Math.PI * radius;
    const strokeDashoffset = circumference - (percentage / 100) * circumference;
    
    return `
        <svg width="120" height="120" style="transform: rotate(-90deg);">
            <circle cx="60" cy="60" r="${radius}" fill="none" stroke="#E8EAED" stroke-width="8"/>
            <circle cx="60" cy="60" r="${radius}" fill="none" stroke="url(#grad)" stroke-width="8" 
                stroke-dasharray="${circumference}" stroke-dashoffset="${strokeDashoffset}"
                style="transition: stroke-dashoffset 0.5s ease; stroke-linecap: round;"/>
            <defs>
                <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" style="stop-color:#6C5CE7;stop-opacity:1" />
                    <stop offset="100%" style="stop-color:#00B894;stop-opacity:1" />
                </linearGradient>
            </defs>
            <text x="60" y="65" text-anchor="middle" fill="#2D3436" font-size="24" font-weight="bold">${percentage}%</text>
        </svg>
    `;
}

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        DailyChallengeSystem,
        StreakSystem,
        moduleChallenges,
        celebrateAchievement,
        milestones,
        getRandomFunFact,
        createModuleChallenge,
        completeChallenge,
        checkMilestones
    };
}
