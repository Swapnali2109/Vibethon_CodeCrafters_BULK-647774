// ========================
// Quiz Management
// ========================

const quizCategories = {
    'ML Basics': [
        { id: 1, topic: 'Supervised Learning', difficulty: 'Beginner' },
        { id: 2, topic: 'Unsupervised Learning', difficulty: 'Beginner' },
        { id: 3, topic: 'Feature Engineering', difficulty: 'Intermediate' }
    ],
    'Neural Networks': [
        { id: 4, topic: 'Perceptrons', difficulty: 'Intermediate' },
        { id: 5, topic: 'Backpropagation', difficulty: 'Intermediate' },
        { id: 6, topic: 'Convolutional Networks', difficulty: 'Advanced' }
    ],
    'Advanced Topics': [
        { id: 7, topic: 'Reinforcement Learning', difficulty: 'Advanced' },
        { id: 8, topic: 'Generative Models', difficulty: 'Advanced' },
        { id: 9, topic: 'Transfer Learning', difficulty: 'Advanced' }
    ]
};

// Quiz difficulty multiplier for points
const difficultyMultiplier = {
    'Beginner': 1,
    'Intermediate': 1.5,
    'Advanced': 2
};

// Problem-solving scenarios for advanced quizzes
const problemScenarios = [
    {
        id: 1,
        title: "Email Spam Classifier",
        description: "Build a machine learning model to classify emails as spam or not spam",
        scenario: "You have a dataset of 10,000 emails with features like word frequency, sender reputation, and content analysis. Your goal is to achieve 95% accuracy.",
        considerations: [
            "Handling class imbalance (90% legitimate, 10% spam)",
            "Feature selection from 500+ features",
            "Real-time prediction latency requirements",
            "User feedback loop for continuous improvement"
        ],
        difficulty: "Intermediate"
    },
    {
        id: 2,
        title: "House Price Prediction",
        description: "Predict house prices based on multiple features",
        scenario: "Given data on house features (size, location, age, etc.), predict the selling price.",
        considerations: [
            "Handling missing values in location data",
            "Feature scaling for different units",
            "Outlier detection for extremely expensive properties",
            "Model interpretability for real estate agents"
        ],
        difficulty: "Beginner"
    },
    {
        id: 3,
        title: "Customer Churn Prediction",
        description: "Predict which customers are likely to leave",
        scenario: "Telecom company wants to identify customers likely to switch to competitors.",
        considerations: [
            "Temporal features (customer lifetime, tenure)",
            "Interaction terms between features",
            "Cost-sensitive learning (retention cost vs acquisition)",
            "Explainability for customer service teams"
        ],
        difficulty: "Intermediate"
    },
    {
        id: 4,
        title: "Time Series Forecasting",
        description: "Forecast stock prices for the next 30 days",
        scenario: "Predict future stock prices based on historical data and market indicators.",
        considerations: [
            "Seasonality and trend detection",
            "Handling data drift",
            "Multiple time horizons",
            "Uncertainty quantification"
        ],
        difficulty: "Advanced"
    }
];

// Interactive code challenges
const codeChallenges = [
    {
        id: 1,
        title: "Implement K-Nearest Neighbors",
        language: "Python",
        difficulty: "Beginner",
        description: "Implement the KNN algorithm from scratch",
        starter: `def knn(X_train, y_train, x_test, k=3):
    # Calculate distances
    distances = []
    for i, x_train in enumerate(X_train):
        dist = # TODO: Calculate Euclidean distance
        distances.append((dist, y_train[i]))
    
    # Sort and get k nearest
    distances.sort()
    k_nearest = distances[:k]
    
    # Return majority vote
    return # TODO: Return most common label`,
        testCases: [
            { input: "([1,2], [3,4], [5,6])", expected: "minimal distance formula" },
            { input: "k=3", expected: "correct voting mechanism" }
        ],
        points: 50
    },
    {
        id: 2,
        title: "Calculate Confusion Matrix",
        language: "Python",
        difficulty: "Beginner",
        description: "Implement function to calculate confusion matrix",
        starter: `def confusion_matrix(y_true, y_pred):
    # TODO: Calculate TP, TN, FP, FN
    tp = # True Positives
    tn = # True Negatives
    fp = # False Positives
    fn = # False Negatives
    
    return [[tp, fp], [fn, tn]]`,
        points: 40
    },
    {
        id: 3,
        title: "Decision Tree Splitting",
        language: "Python",
        difficulty: "Intermediate",
        description: "Implement entropy calculation for decision tree splits",
        starter: `import math

def calculate_entropy(y):
    # TODO: Calculate Shannon entropy
    # entropy = -Σ(p_i * log2(p_i))
    pass

def information_gain(y_parent, y_left, y_right):
    # TODO: Calculate information gain
    # IG = entropy(parent) - weighted average of child entropies
    pass`,
        points: 75
    },
    {
        id: 4,
        title: "Neural Network Forward Pass",
        language: "JavaScript",
        difficulty: "Intermediate",
        description: "Implement forward propagation for a neural network",
        starter: `class NeuralNetwork {
    constructor(hiddenSize) {
        this.hiddenSize = hiddenSize;
        this.weights = this.initWeights();
    }
    
    forward(input) {
        // TODO: Implement hidden layer computation
        let hidden = this.matrixMultiply(input, this.weights.w1);
        hidden = this.relu(hidden);
        
        // TODO: Implement output layer
        let output = // Complete this
        return output;
    }
    
    relu(x) { return Math.max(0, x); }
    matrixMultiply(a, b) { /* implement */ }
}`,
        points: 100
    }
];

// Quiz analytics tracking
class QuizAnalytics {
    constructor() {
        this.attempts = [];
        this.performance = {};
    }

    recordAttempt(quizId, score, difficulty) {
        this.attempts.push({
            quizId,
            score,
            difficulty,
            timestamp: new Date(),
            points: Math.round(score * difficultyMultiplier[difficulty])
        });
    }

    getPerformanceStats(quizId) {
        const quizAttempts = this.attempts.filter(a => a.quizId === quizId);
        if (quizAttempts.length === 0) return null;

        const scores = quizAttempts.map(a => a.score);
        return {
            average: scores.reduce((a, b) => a + b) / scores.length,
            bestScore: Math.max(...scores),
            totalAttempts: quizAttempts.length,
            totalPoints: quizAttempts.reduce((sum, a) => sum + a.points, 0),
            lastAttempt: quizAttempts[quizAttempts.length - 1].timestamp
        };
    }

    getLearningPath() {
        // Suggest next quizzes based on performance
        const avgScore = this.attempts.length > 0 ? 
            this.attempts.reduce((sum, a) => sum + a.score, 0) / this.attempts.length : 0;

        if (avgScore < 60) {
            return "Focus on fundamentals. Practice Beginner level quizzes.";
        } else if (avgScore < 80) {
            return "Good progress! Try Intermediate level quizzes.";
        } else {
            return "Excellent! Ready for Advanced level challenges.";
        }
    }
}

// Create global analytics instance
const quizAnalytics = new QuizAnalytics();

// Load suggested quizzes based on user performance
function getSuggestedQuizzes(userLevel) {
    const suggestions = [];
    
    for (const category in quizCategories) {
        const categoryQuizzes = quizCategories[category];
        const matchingQuizzes = categoryQuizzes.filter(q => {
            const diffLevel = { 'Beginner': 1, 'Intermediate': 2, 'Advanced': 3 };
            return diffLevel[q.difficulty] === userLevel || diffLevel[q.difficulty] === userLevel + 1;
        });
        
        if (matchingQuizzes.length > 0) {
            suggestions.push({
                category,
                quizzes: matchingQuizzes
            });
        }
    }
    
    return suggestions;
}

// Adaptive quiz generation
function generateAdaptiveQuiz(userPerformance) {
    const difficulty = userPerformance > 80 ? 'Advanced' : 
                       userPerformance > 60 ? 'Intermediate' : 'Beginner';
    
    const applicableScenarios = problemScenarios.filter(s => s.difficulty === difficulty);
    const scenario = applicableScenarios[Math.floor(Math.random() * applicableScenarios.length)];
    
    return {
        type: 'scenario',
        scenario,
        difficulty,
        timeLimit: difficulty === 'Advanced' ? 30 : 20
    };
}

// Quiz progress tracking
function trackQuizProgress(userId, quizId, score, difficulty) {
    quizAnalytics.recordAttempt(quizId, score, difficulty);
    
    const stats = quizAnalytics.getPerformanceStats(quizId);
    return {
        stats,
        recommendation: quizAnalytics.getLearningPath(),
        nextSuggestions: getSuggestedQuizzes(Math.floor(score / 25)) // Map score to level
    };
}

// Gamification achievements for quizzes
const quizAchievements = {
    'first_quiz': { name: '📚 First Steps', description: 'Complete your first quiz', icon: '📚' },
    'perfect_score': { name: '🎯 Perfect Score', description: 'Score 100% on a quiz', icon: '🎯' },
    'streak_5': { name: '🔥 On Fire', description: 'Score 80%+ on 5 consecutive quizzes', icon: '🔥' },
    'master_category': { name: '🏆 Category Master', description: 'Complete all quizzes in a category', icon: '🏆' },
    'speed_demon': { name: '⚡ Speed Demon', description: 'Complete a quiz in half the time limit', icon: '⚡' },
    'challenge_accepted': { name: '💪 Challenge Accepted', description: 'Complete an Advanced quiz', icon: '💪' }
};

function checkQuizAchievements(userId, score, difficulty, timeSpent, timeLimit) {
    const achievements = [];
    
    // Check difficulty-based achievements
    if (difficulty === 'Advanced') {
        achievements.push('challenge_accepted');
    }
    
    if (score === 100) {
        achievements.push('perfect_score');
    }
    
    if (timeSpent < timeLimit / 2) {
        achievements.push('speed_demon');
    }
    
    return achievements;
}

// Export for use in main.js
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        quizCategories,
        problemScenarios,
        codeChallenges,
        quizAnalytics,
        getSuggestedQuizzes,
        generateAdaptiveQuiz,
        trackQuizProgress,
        checkQuizAchievements
    };
}
